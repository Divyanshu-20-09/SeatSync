# SeatSync Backend Integration Guide (Supabase)

This guide provides step-by-step instructions to transition SeatSync from the current **Mock Authentication (localStorage)** to a real-time **Supabase Backend**.

## 1. Supabase Project Setup

1.  Create a new project at [Supabase](https://supabase.com).
2.  Go to **Project Settings > API** and note your `Project URL` and `Anon Key`.
3.  Go to **Authentication > Providers** and enable **Email** (or other providers if needed).
4.  Disable "Confirm Email" for development if you want immediate access.

## 2. Database Schema (SQL)

Run the following SQL in the Supabase SQL Editor to create the necessary tables:

```sql
-- Profiles table (extends Supabase Auth)
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  email text unique,
  role text check (role in ('student', 'admin')),
  registration_no text unique, -- For students
  admin_id text unique,        -- For admins
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Seats table
create table public.seats (
  id uuid default gen_random_uuid() primary key,
  number text not null unique,
  floor integer not null,
  type text check (type in ('window', 'aisle', 'standard')),
  status text default 'available' check (status in ('available', 'occupied', 'reserved', 'maintenance')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Bookings table
create table public.bookings (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  seat_id uuid references public.seats on delete cascade not null,
  otp text not null,
  status text default 'pending' check (status in ('pending', 'active', 'completed', 'cancelled')),
  expires_at timestamp with time zone not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- History table
create table public.history (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  seat_number text not null,
  floor integer not null,
  type text not null,
  duration text,
  status text not null,
  date date default current_date
);

-- Enable Row Level Security (RLS)
alter table public.profiles enable row level security;
alter table public.seats enable row level security;
alter table public.bookings enable row level security;
alter table public.history enable row level security;

-- RLS Policies (Examples)
create policy "Public profiles are viewable by everyone." on public.profiles for select using (true);
create policy "Users can update own profile." on public.profiles for update using (auth.uid() = id);
create policy "Seats are viewable by everyone." on public.seats for select using (true);
create policy "Admins can manage seats." on public.seats for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
);
```

## 3. Frontend Re-integration Steps

### A. Install Dependencies
```bash
npm install @supabase/supabase-js
```

### B. Environment Variables
Add these to your `.env` file:
```env
VITE_SUPABASE_URL=your_project_url
VITE_SUPABASE_ANON_KEY=your_anon_key
```

### C. Supabase Client (`src/lib/supabase.ts`)
```typescript
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
```

### D. Update `AuthContext.tsx`
Replace the mock logic with Supabase Auth calls:
- `login`: Use `supabase.auth.signInWithPassword`.
- `signUp`: Use `supabase.auth.signUp` and then insert into `public.profiles`.
- `logout`: Use `supabase.auth.signOut`.

### E. Update `useSeats.ts`
Replace `localStorage` logic with Supabase Realtime:
- Use `supabase.from('seats').select('*')` for initial load.
- Use `supabase.channel('seats').on('postgres_changes', ...)` for real-time updates.
- Update `updateSeatStatus` to use `supabase.from('seats').update(...)`.

### F. Update `History.tsx`
- Fetch history from `supabase.from('history').select('*').eq('user_id', auth.uid())`.

## 4. Final Touches
- Ensure all `localStorage` calls are removed.
- Update the `QRScanner` to verify against the database.
- Test the flow: Sign Up -> Login -> Book Seat -> Verify OTP -> Checkout.

---
*This guide was generated to assist in the final production deployment of SeatSync.*
