export type UserRole = 'student' | 'admin';

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  registration_no?: string;
  admin_id?: string;
  created_at: string;
}

export interface Seat {
  id: string;
  number: string;
  floor: number;
  type: 'window' | 'aisle' | 'standard';
  status: 'available' | 'occupied' | 'reserved';
  created_at: string;
}

export interface Booking {
  id: string;
  seat_id: string;
  user_id: string;
  otp: string | null;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  expires_at: string | null;
  verified_at: string | null; // This is effectively check-in time
  checkout_at: string | null; // This is the check-out time
  created_at: string;
  seats?: Seat;
  profiles?: Profile;
}

export interface Log {
  id: string;
  action: string;
  details: any;
  created_at: string;
}
