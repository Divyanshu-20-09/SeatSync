import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import type { Profile, UserRole } from '../types';

interface AuthContextType {
  user: any;
  profile: Profile | null;
  profileError: string | null;
  loading: boolean;
  login: (userId: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, metadata: { full_name: string; role: UserRole; registration_no?: string; admin_id?: string }) => Promise<{ error: any }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [profileError, setProfileError] = useState<string | null>(null);

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Check active session
        const { data: { session } } = await supabase.auth.getSession();
        setUser(session?.user ?? null);
        if (session?.user) {
          await fetchProfile(session.user.id);
        } else {
          setLoading(false);
        }

        // Listen for auth changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
          setUser(session?.user ?? null);
          if (session?.user) {
            fetchProfile(session.user.id);
          } else {
            setProfile(null);
            setProfileError(null);
            setLoading(false);
          }
        });

        return () => subscription.unsubscribe();
      } catch (error) {
        console.error('Supabase initialization failed:', error);
        setLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const fetchProfile = async (userId: string) => {
    try {
      setProfileError(null);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // No profile found
          setProfile(null);
        } else {
          throw error;
        }
      } else {
        setProfile(data);
      }
    } catch (error: any) {
      console.error('Error fetching profile:', error);
      setProfileError(error.message || 'Failed to load user profile');
    } finally {
      setLoading(false);
    }
  };

  const login = async (userId: string, password: string) => {
    try {
      console.log('Attempting login for:', userId);
      // Step 1: Find the email associated with the Registration No or Admin ID
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('email, role')
        .or(`registration_no.eq.${userId},admin_id.eq.${userId}`)
        .maybeSingle();

      if (profileError) {
        console.error('Profile fetch error:', profileError);
        return { error: profileError };
      }
      
      if (!profileData) {
        console.warn('No profile found for ID:', userId);
        return { error: { message: 'User ID not found. Please check your credentials or sign up.' } };
      }

      console.log('Profile found:', profileData.email, 'Role:', profileData.role);

      // Step 2: Sign in with the found email and provided password
      const { data, error } = await supabase.auth.signInWithPassword({
        email: profileData.email,
        password,
      });

      if (error) {
        console.error('Auth sign in error:', error);
        throw error;
      }
      return { error: null };
    } catch (error: any) {
      console.error('Login catch error:', error);
      return { error };
    }
  };

  const signUp = async (email: string, password: string, metadata: { full_name: string; role: UserRole; registration_no?: string; admin_id?: string }) => {
    try {
      // Step 1: Sign up user
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: metadata.full_name,
            role: metadata.role,
            registration_no: metadata.registration_no,
            admin_id: metadata.admin_id,
          }
        }
      });

      if (error) throw error;

      if (data.user) {
        // Step 2: Create/Update profile record (Upsert to handle trigger conflicts)
        const { error: profileError } = await supabase
          .from('profiles')
          .upsert({
            id: data.user.id,
            email,
            full_name: metadata.full_name,
            role: metadata.role,
            registration_no: metadata.registration_no,
            admin_id: metadata.admin_id,
          });

        if (profileError) {
          console.warn('Manual profile upsert failed, likely handled by trigger:', profileError);
          // We don't throw here because the trigger might have already handled it
        }
      }

      return { error: null };
    } catch (error: any) {
      console.error('Sign up error:', error);
      return { error };
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
  };

  return (
    <AuthContext.Provider value={{ user, profile, profileError, loading, login, signUp, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
