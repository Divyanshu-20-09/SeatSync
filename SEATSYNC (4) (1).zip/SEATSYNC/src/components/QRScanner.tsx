import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Button, Card } from './UI';
import { Camera, Upload, X, CheckCircle2, AlertCircle, Loader2, Keyboard } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { Input } from './UI';

interface QRScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
  title?: string;
}

export function QRScanner({ onScan, onClose, title = "Scan QR Code" }: QRScannerProps) {
  const [scanMethod, setScanMethod] = useState<'camera' | 'upload' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);

  useEffect(() => {
    if (scanMethod === 'camera') {
      const html5QrCode = new Html5Qrcode("reader");
      html5QrCodeRef.current = html5QrCode;
      
      const config = { fps: 10, qrbox: { width: 250, height: 250 } };
      
      html5QrCode.start(
        { facingMode: "environment" },
        config,
        (decodedText) => {
          onScan(decodedText);
          html5QrCode.stop().catch(console.error);
          setScanMethod(null);
        },
        (errorMessage) => {
          // Silent error for continuous scanning
        }
      ).catch((err) => {
        console.error("Failed to start camera:", err);
        setError("Could not access the camera. Please ensure you have granted camera permissions.");
      });
    }

    return () => {
      if (html5QrCodeRef.current && html5QrCodeRef.current.isScanning) {
        html5QrCodeRef.current.stop().catch(console.error);
      }
    };
  }, [scanMethod, onScan]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanning(true);
    setError(null);

    try {
      // Create a temporary reader element if it doesn't exist
      let readerElement = document.getElementById('reader-hidden');
      if (!readerElement) {
        readerElement = document.createElement('div');
        readerElement.id = 'reader-hidden';
        readerElement.style.display = 'none';
        document.body.appendChild(readerElement);
      }

      const html5QrCode = new Html5Qrcode("reader-hidden");
      html5QrCodeRef.current = html5QrCode;
      
      const decodedText = await html5QrCode.scanFile(file, true);
      onScan(decodedText);
      setScanMethod(null);
      
      // Cleanup
      html5QrCode.clear();
    } catch (err: any) {
      console.error('QR File Scan Error:', err);
      setError("Could not find a valid QR code in this image. Please ensure the QR code is clear and not blurry.");
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-lg bg-white rounded-[2.5rem] shadow-2xl overflow-hidden relative"
      >
        {/* Header */}
        <div className="p-8 border-b border-slate-100 flex items-center justify-between">
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">{title}</h3>
            <p className="text-sm text-slate-500 font-medium">Verify your presence at the seat</p>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-10 w-10 p-0 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50" 
            onClick={onClose}
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-8">
          {!scanMethod ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button 
                onClick={() => setScanMethod('camera')}
                className="flex flex-col items-center justify-center gap-4 p-6 rounded-[2rem] bg-indigo-50 border-2 border-transparent hover:border-indigo-200 hover:bg-indigo-100/50 transition-all group"
              >
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-indigo-600 shadow-sm group-hover:scale-110 transition-transform">
                  <Camera className="w-6 h-6" />
                </div>
                <div className="text-center">
                  <p className="font-black text-indigo-900 text-sm">Camera</p>
                  <p className="text-[8px] text-indigo-600 font-black uppercase tracking-widest mt-1">Mobile</p>
                </div>
              </button>

              <button 
                onClick={() => setScanMethod('upload')}
                className="flex flex-col items-center justify-center gap-4 p-6 rounded-[2rem] bg-slate-50 border-2 border-transparent hover:border-slate-200 hover:bg-slate-100 transition-all group"
              >
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-slate-600 shadow-sm group-hover:scale-110 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <div className="text-center">
                  <p className="font-black text-slate-900 text-sm">Upload</p>
                  <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest mt-1">Laptops</p>
                </div>
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="relative aspect-square max-w-[300px] mx-auto bg-slate-900 rounded-[2rem] overflow-hidden border-4 border-slate-100 shadow-inner">
                  {scanMethod === 'camera' && (
                    <div id="reader" className="w-full h-full" />
                  )}
                  
                  {scanMethod === 'upload' && (
                    <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
                      {isScanning ? (
                        <div className="space-y-4">
                          <Loader2 className="w-12 h-12 text-indigo-500 animate-spin mx-auto" />
                          <p className="text-slate-400 font-black text-xs uppercase tracking-widest">Processing Image...</p>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div className="w-20 h-20 bg-slate-800 rounded-3xl flex items-center justify-center text-slate-400 mx-auto">
                            <Upload className="w-10 h-10" />
                          </div>
                          <div className="space-y-2">
                            <p className="text-white font-black">Select QR Image</p>
                            <p className="text-slate-500 text-xs font-medium px-4">Upload a screenshot or photo of the seat's QR code</p>
                          </div>
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="hidden" 
                            id="qr-upload" 
                            onChange={handleFileUpload}
                          />
                          <Button 
                            onClick={() => document.getElementById('qr-upload')?.click()}
                            className="h-12 px-8 rounded-xl bg-white text-slate-900 hover:bg-slate-100"
                          >
                            Choose File
                          </Button>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Hidden reader for file scanning */}
                  <div id="reader-hidden" className="hidden" />
                </div>

              {error && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600"
                >
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <p className="text-xs font-bold">{error}</p>
                </motion.div>
              )}

              <div className="flex justify-center">
                <Button 
                  variant="ghost" 
                  className="text-slate-400 font-black text-[10px] uppercase tracking-widest hover:text-slate-600"
                  onClick={() => setScanMethod(null)}
                >
                  Switch Method
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Security Notice */}
        <div className="px-8 py-6 bg-slate-50 border-t border-slate-100 flex items-center gap-4">
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-emerald-500 shadow-sm">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="space-y-0.5">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Security Protocol</p>
            <p className="text-xs text-slate-600 font-bold">OTPs are unique and expire after 5 minutes.</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
