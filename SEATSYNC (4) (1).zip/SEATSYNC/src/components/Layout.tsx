import { ReactNode, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link, useLocation } from 'react-router-dom';
import { 
  LogOut, 
  User, 
  Library, 
  LayoutDashboard, 
  Settings, 
  History,
  Menu,
  X,
  ChevronRight,
  Bell
} from 'lucide-react';
import { Button } from './UI';
import { toast } from 'sonner';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export function Layout({ children }: { children: ReactNode }) {
  const { profile, logout } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();

  async function handleSignOut() {
    logout();
    toast.success('Signed out successfully');
  }

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-slate-50 flex overflow-hidden">
      {/* Sidebar */}
      <AnimatePresence mode="wait">
        {isSidebarOpen && (
          <motion.aside 
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="w-72 bg-white border-r border-slate-200 flex flex-col z-40 fixed inset-y-0 lg:relative"
          >
            <div className="p-6 flex items-center justify-between">
              <Link to="/" className="flex items-center gap-3">
                <div className="bg-indigo-600 p-2 rounded-xl shadow-lg shadow-indigo-100">
                  <Library className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-black text-slate-900 tracking-tight">SeatSync</span>
              </Link>
              <button 
                onClick={() => setIsSidebarOpen(false)}
                className="lg:hidden p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-4 py-2">
              <div className="bg-slate-50 rounded-2xl p-4 mb-6">
                <p className="text-[10px] uppercase tracking-[0.2em] font-black text-slate-400 mb-3">Quick Actions</p>
                <div className="grid grid-cols-2 gap-2">
                  <button className="flex flex-col items-center justify-center p-3 bg-white rounded-xl border border-slate-100 shadow-sm hover:border-indigo-200 hover:bg-indigo-50/30 transition-all group">
                    <Bell className="w-5 h-5 text-slate-400 group-hover:text-indigo-600 mb-1" />
                    <span className="text-[10px] font-bold text-slate-600">Alerts</span>
                  </button>
                  <Link to="/history" className="flex flex-col items-center justify-center p-3 bg-white rounded-xl border border-slate-100 shadow-sm hover:border-indigo-200 hover:bg-indigo-50/30 transition-all group">
                    <History className="w-5 h-5 text-slate-400 group-hover:text-indigo-600 mb-1" />
                    <span className="text-[10px] font-bold text-slate-600">History</span>
                  </Link>
                </div>
              </div>
            </div>

            <nav className="flex-1 px-4 space-y-1.5 overflow-y-auto">
              <p className="px-4 text-[10px] uppercase tracking-[0.2em] font-black text-slate-400 mb-2">Main Menu</p>
              <NavItem to="/" icon={<LayoutDashboard className="w-5 h-5" />} label="Dashboard" active={isActive('/')} />
              {profile?.role === 'admin' ? (
                <>
                  <NavItem to="/management" icon={<Settings className="w-5 h-5" />} label="Management" active={isActive('/management')} />
                  <NavItem to="/history" icon={<History className="w-5 h-5" />} label="System Logs" active={isActive('/history')} />
                  <NavItem to="/users" icon={<User className="w-5 h-5" />} label="User Access" active={isActive('/users')} />
                </>
              ) : (
                <>
                  <NavItem to="/history" icon={<History className="w-5 h-5" />} label="My Bookings" active={isActive('/history')} />
                  <NavItem to="/profile" icon={<User className="w-5 h-5" />} label="Profile Settings" active={isActive('/profile')} />
                </>
              )}
            </nav>

            <div className="p-4 mt-auto">
              <div className="bg-slate-900 rounded-2xl p-4 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full -mr-12 -mt-12 blur-2xl group-hover:bg-indigo-500/20 transition-colors" />
                <Link to="/profile" className="flex items-center gap-3 relative z-10">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500 flex items-center justify-center text-white font-black shadow-lg shadow-indigo-500/20">
                    {profile?.full_name?.charAt(0) || 'U'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-white truncate">{profile?.full_name}</p>
                    <p className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider">
                      {profile?.role === 'admin' ? profile.admin_id : profile?.registration_no}
                    </p>
                  </div>
                </Link>
                <button 
                  onClick={handleSignOut}
                  className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 bg-white/10 hover:bg-red-500/20 text-white hover:text-red-200 rounded-xl text-xs font-bold transition-all border border-white/5"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 z-30">
          <div className="flex items-center gap-4">
            {!isSidebarOpen && (
              <button 
                onClick={() => setIsSidebarOpen(true)}
                className="p-2 text-slate-500 hover:bg-slate-50 rounded-lg transition-colors"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}
            <div className="flex items-center gap-2 text-sm font-medium text-slate-400">
              <span>SeatSync</span>
              <ChevronRight className="w-4 h-4" />
              <span className="text-slate-900 font-bold capitalize">{location.pathname.replace('/', '') || 'Dashboard'}</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-xl transition-all relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
            </button>
            <div className="h-8 w-[1px] bg-slate-100 mx-2" />
            <Link to="/profile" className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-900 leading-none">{profile?.full_name}</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">
                  {profile?.role === 'admin' ? profile.admin_id : profile?.registration_no}
                </p>
              </div>
              <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold text-xs">
                {profile?.full_name?.charAt(0)}
              </div>
            </Link>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-slate-50/50 pb-24 lg:pb-8">
          <div className="p-4 md:p-8 max-w-7xl mx-auto">
            {children}
          </div>
        </main>

        {/* Bottom Navigation for Mobile */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-6 py-3 flex items-center justify-between z-40 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
          <MobileNavItem to="/" icon={<LayoutDashboard className="w-6 h-6" />} active={isActive('/')} />
          <MobileNavItem to="/history" icon={<History className="w-6 h-6" />} active={isActive('/history')} />
          {profile?.role === 'admin' && (
            <MobileNavItem to="/management" icon={<Settings className="w-6 h-6" />} active={isActive('/management')} />
          )}
          <MobileNavItem to="/profile" icon={<User className="w-6 h-6" />} active={isActive('/profile')} />
        </nav>
      </div>
    </div>
  );
}

function MobileNavItem({ to, icon, active }: { to: string; icon: ReactNode; active: boolean }) {
  return (
    <Link 
      to={to} 
      className={cn(
        "p-2 rounded-xl transition-all",
        active ? "text-indigo-600 bg-indigo-50" : "text-slate-400"
      )}
    >
      {icon}
    </Link>
  );
}

function NavItem({ icon, label, to, active = false }: { icon: ReactNode; label: string; to: string; active?: boolean }) {
  return (
    <Link
      to={to}
      className={cn(
        'w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all group relative',
        active 
          ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' 
          : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
      )}
    >
      <span className={cn(
        "transition-transform group-hover:scale-110",
        active ? "text-white" : "text-slate-400 group-hover:text-indigo-600"
      )}>
        {icon}
      </span>
      {label}
      {active && (
        <motion.div 
          layoutId="activeNav"
          className="absolute right-2 w-1.5 h-1.5 bg-white rounded-full"
        />
      )}
    </Link>
  );
}
