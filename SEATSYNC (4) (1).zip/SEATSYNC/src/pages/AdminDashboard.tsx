import React, { useState, useEffect } from 'react';
import { useSeats } from '../hooks/useSeats';
import { supabase } from '../lib/supabase';
import { Button, Card, Input, Modal, ConfirmModal } from '../components/UI';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';
import { Seat } from '../types';
import { 
  Users, 
  CheckCircle2, 
  XCircle, 
  Activity,
  Plus,
  Trash2,
  User,
  Clock,
  ShieldCheck,
  QrCode,
  Download,
  Eye,
  TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';
import { QRCodeSVG } from 'qrcode.react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';

export default function AdminDashboard() {
  const { seats, loading, updateSeatStatus, addSeat, removeSeat } = useSeats();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [viewingQR, setViewingQR] = useState<Seat | null>(null);
  const [newSeatNumber, setNewSeatNumber] = useState('');
  const [newSeatFloor, setNewSeatFloor] = useState('1');
  const [newSeatType, setNewSeatType] = useState<'window' | 'aisle' | 'standard'>('standard');
  const [activities, setActivities] = useState<any[]>([]);
  const [globalHistory, setGlobalHistory] = useState<any[]>([]);
  const [isPrintAllModalOpen, setIsPrintAllModalOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [confirmRelease, setConfirmRelease] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      // Fetch recent global history
      const { data: historyData } = await supabase
        .from('bookings')
        .select('*, seats(*), profiles(*)')
        .in('status', ['completed', 'cancelled'])
        .order('created_at', { ascending: false })
        .limit(10);
      
      setGlobalHistory(historyData || []);

      // Fetch recent activities (all booking changes)
      const { data: activityData } = await supabase
        .from('bookings')
        .select('*, seats(*), profiles(*)')
        .order('created_at', { ascending: false })
        .limit(5);
      
      const formattedActivities = (activityData || []).map(b => ({
        action: b.status === 'pending' ? 'Seat Reserved' : b.status === 'active' ? 'Check-in' : 'Check-out',
        user: b.profiles?.full_name || 'Unknown',
        time: new Date(b.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: b.status,
        seat: b.seats?.number
      }));
      setActivities(formattedActivities);
    } catch (error) {
      console.error('Error fetching admin data:', error);
    }
  };

  useEffect(() => {
    fetchData();
    
    // Real-time subscription for bookings
    const channel = supabase
      .channel('admin-updates')
      .on('postgres_changes', { event: '*', table: 'bookings', schema: 'public' }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const stats = {
    total: seats.length,
    occupied: seats.filter(s => s.status === 'occupied').length,
    available: seats.filter(s => s.status === 'available').length,
    reserved: seats.filter(s => s.status === 'reserved').length,
  };

  const occupancyRate = stats.total > 0 ? Math.round((stats.occupied / stats.total) * 100) : 0;

  async function handleAddSeat() {
    addSeat({
      number: newSeatNumber,
      floor: parseInt(newSeatFloor),
      type: newSeatType,
    });
    toast.success('Seat added successfully');
    setIsAddModalOpen(false);
  }

  async function handleRemoveSeat(id: string) {
    removeSeat(id);
    toast.success('Seat removed');
  }

  async function handleForceRelease(seatId: string) {
    updateSeatStatus(seatId, 'available');
    toast.success('Seat released manually');
  }

  if (loading) return null;

  return (
    <div className="space-y-6 md:space-y-8 pb-20 px-4 md:px-0">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-6 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/30">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest">
            <ShieldCheck className="w-3 h-3" />
            Admin Control Panel
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">System Overview</h1>
          <p className="text-sm md:text-base text-slate-500 font-medium">Real-time monitoring and seat management</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <Button 
            variant="outline" 
            className="h-12 px-6 rounded-xl border-slate-200 hover:bg-slate-50"
            onClick={() => setIsPrintAllModalOpen(true)}
          >
            <Download className="w-4 h-4 mr-2" />
            Print All
          </Button>
          <Button onClick={() => setIsAddModalOpen(true)} className="h-12 px-8 rounded-xl shadow-xl shadow-indigo-100">
            <Plus className="w-4 h-4 mr-2" />
            Add New Seat
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <StatCard 
              icon={<Activity className="text-indigo-600" />} 
              label="Total Capacity" 
              value={stats.total} 
              color="bg-indigo-50" 
              trend="+2 this week"
            />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <StatCard 
              icon={<CheckCircle2 className="text-emerald-600" />} 
              label="Available Now" 
              value={stats.available} 
              color="bg-emerald-50" 
              trend="High availability"
            />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <StatCard 
              icon={<XCircle className="text-rose-600" />} 
              label="Occupied" 
              value={stats.occupied} 
              color="bg-rose-50" 
              trend={`${occupancyRate}% occupancy`}
            />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <StatCard 
              icon={<Clock className="text-amber-600" />} 
              label="Reserved" 
              value={stats.reserved} 
              color="bg-amber-50" 
              trend="Expiring soon: 3"
            />
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="lg:col-span-1"
        >
          <Card className="h-full p-6 md:p-8 border-none shadow-xl shadow-slate-200/30 bg-white rounded-[2rem] flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                Occupancy Distribution
              </h3>
            </div>
            <div className="flex-1 min-h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Available', value: stats.available },
                      { name: 'Occupied', value: stats.occupied },
                      { name: 'Reserved', value: stats.reserved },
                    ]}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    <Cell fill="#6366f1" />
                    <Cell fill="#f43f5e" />
                    <Cell fill="#f59e0b" />
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-4">
              <div className="text-center">
                <p className="text-[10px] font-black text-indigo-600 uppercase">Avail</p>
                <p className="text-lg font-black text-slate-900">{stats.available}</p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-black text-rose-600 uppercase">Occu</p>
                <p className="text-lg font-black text-slate-900">{stats.occupied}</p>
              </div>
              <div className="text-center">
                <p className="text-[10px] font-black text-amber-600 uppercase">Resv</p>
                <p className="text-lg font-black text-slate-900">{stats.reserved}</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Live Monitoring Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="lg:col-span-2"
        >
          <Card className="border-none shadow-2xl shadow-slate-200/40 overflow-hidden rounded-[1.5rem] md:rounded-[2.5rem]">
            <div className="px-6 md:px-10 py-6 md:py-8 border-b border-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white">
              <div className="space-y-1">
                <h3 className="text-lg md:text-xl font-black text-slate-900 flex items-center gap-2">
                  <div className="w-2 h-6 bg-indigo-600 rounded-full" />
                  Live Seat Management
                </h3>
                <p className="text-xs md:text-sm text-slate-400 font-medium">Manage individual seat statuses and assignments</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="hidden sm:flex -space-x-3">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-xl border-4 border-white bg-slate-100 flex items-center justify-center text-xs font-black text-slate-400 shadow-sm">
                      U{i}
                    </div>
                  ))}
                </div>
                <div className="hidden sm:block h-10 w-[1px] bg-slate-100 mx-2" />
                <div className="text-right">
                  <p className="text-sm font-black text-slate-900 leading-none">128</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Total Users</p>
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[600px]">
                <thead>
                  <tr className="bg-slate-50/50 text-slate-400 text-[10px] uppercase tracking-[0.2em] font-black">
                    <th className="px-6 md:px-10 py-5">Seat Details</th>
                    <th className="px-6 md:px-10 py-5">Floor</th>
                    <th className="px-6 md:px-10 py-5">Type</th>
                    <th className="px-6 md:px-10 py-5">Status</th>
                    <th className="px-6 md:px-10 py-5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {seats.map((seat) => (
                    <tr key={seat.id} className="hover:bg-slate-50/30 transition-colors group">
                      <td className="px-6 md:px-10 py-6">
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center text-base md:text-lg font-black shadow-sm transition-transform group-hover:scale-110",
                            seat.status === 'available' ? "bg-indigo-50 text-indigo-600" : "bg-slate-100 text-slate-400"
                          )}>
                            {seat.number.split('-')[1]}
                          </div>
                          <div>
                            <p className="font-black text-slate-900 text-sm md:text-base">{seat.number}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">ID: {seat.id.split('-')[1]}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 md:px-10 py-6">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-500">
                            F{seat.floor}
                          </span>
                          <span className="text-sm font-bold text-slate-600">Level {seat.floor}</span>
                        </div>
                      </td>
                      <td className="px-6 md:px-10 py-6">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1.5 rounded-lg">
                          {seat.type}
                        </span>
                      </td>
                      <td className="px-6 md:px-10 py-6">
                        <div className={cn(
                          "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest",
                          seat.status === 'available' && "bg-emerald-50 text-emerald-600",
                          seat.status === 'occupied' && "bg-rose-50 text-rose-600",
                          seat.status === 'reserved' && "bg-amber-50 text-amber-600"
                        )}>
                          <div className={cn(
                            "w-1.5 h-1.5 rounded-full",
                            seat.status === 'available' && "bg-emerald-500 animate-pulse",
                            seat.status === 'occupied' && "bg-rose-500",
                            seat.status === 'reserved' && "bg-amber-500"
                          )} />
                          {seat.status}
                        </div>
                      </td>
                      <td className="px-6 md:px-10 py-6 text-right">
                        <div className="flex items-center justify-end gap-2 md:opacity-0 group-hover:opacity-100 transition-all md:translate-x-4 group-hover:translate-x-0">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-9 w-9 p-0 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-indigo-50" 
                            onClick={() => setViewingQR(seat)}
                          >
                            <QrCode className="w-4 h-4" />
                          </Button>
                          {seat.status !== 'available' && (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="h-9 px-4 text-[10px] font-black uppercase tracking-widest rounded-xl border-slate-200 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200" 
                              onClick={() => setConfirmRelease(seat.id)}
                            >
                              Force Release
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-9 w-9 p-0 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50" 
                            onClick={() => setConfirmDelete(seat.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </motion.div>

        {/* Activity Log */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="h-full border-none shadow-2xl shadow-slate-200/40 rounded-[1.5rem] md:rounded-[2.5rem] p-6 md:p-8 space-y-6">
            <div className="space-y-1">
              <h3 className="text-lg md:text-xl font-black text-slate-900 flex items-center gap-2">
                <div className="w-2 h-6 bg-emerald-500 rounded-full" />
                Live Activity
              </h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">System Logs</p>
            </div>

            <div className="space-y-6">
              {activities.length > 0 ? activities.map((log, i) => (
                <div key={i} className="flex gap-4 group">
                  <div className="relative">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center shadow-sm transition-transform group-hover:scale-110",
                      log.status === 'active' && "bg-indigo-50 text-indigo-600",
                      log.status === 'available' && "bg-emerald-50 text-emerald-600",
                      log.status === 'system' && "bg-slate-50 text-slate-600",
                      log.status === 'pending' && "bg-amber-50 text-amber-600"
                    )}>
                      {log.status === 'active' ? <User className="w-4 h-4" /> : <Activity className="w-4 h-4" />}
                    </div>
                    {i !== activities.length - 1 && <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[1px] h-6 bg-slate-100" />}
                  </div>
                  <div className="space-y-0.5">
                    <p className="text-sm font-black text-slate-900">{log.action}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{log.user}</span>
                      <span className="text-[10px] text-slate-300">•</span>
                      <span className="text-[10px] font-bold text-slate-400">{log.time}</span>
                    </div>
                  </div>
                </div>
              )) : (
                <div className="py-12 text-center space-y-4">
                  <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto">
                    <Activity className="w-6 h-6 text-slate-300" />
                  </div>
                  <p className="text-slate-400 font-bold text-sm">No recent activity</p>
                </div>
              )}
            </div>

            <Button variant="ghost" className="w-full text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-indigo-600">
              View All Logs
            </Button>
          </Card>
        </motion.div>
      </div>

      {/* Session History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <Card className="border-none shadow-2xl shadow-slate-200/40 overflow-hidden rounded-[1.5rem] md:rounded-[2.5rem]">
          <div className="px-6 md:px-10 py-6 md:py-8 border-b border-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white">
            <div className="space-y-1">
              <h3 className="text-lg md:text-xl font-black text-slate-900 flex items-center gap-2">
                <div className="w-2 h-6 bg-emerald-600 rounded-full" />
                Recent Session History
              </h3>
              <p className="text-xs md:text-sm text-slate-400 font-medium">Track student check-in and check-out times</p>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="bg-slate-50/50 text-slate-400 text-[10px] uppercase tracking-[0.2em] font-black">
                  <th className="px-6 md:px-10 py-5">Student</th>
                  <th className="px-6 md:px-10 py-5">Seat</th>
                  <th className="px-6 md:px-10 py-5">Date</th>
                  <th className="px-6 md:px-10 py-5">Check-in</th>
                  <th className="px-6 md:px-10 py-5">Check-out</th>
                  <th className="px-6 md:px-10 py-5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {globalHistory.length > 0 ? globalHistory.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/30 transition-colors group">
                    <td className="px-6 md:px-10 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-50 flex items-center justify-center text-[10px] font-black text-indigo-600">
                          {item.profiles?.full_name?.charAt(0) || '?'}
                        </div>
                        <p className="font-black text-slate-900 text-sm">{item.profiles?.full_name || 'Unknown'}</p>
                      </div>
                    </td>
                    <td className="px-6 md:px-10 py-6 font-bold text-slate-600 text-sm">{item.seats?.number || 'Unknown'}</td>
                    <td className="px-6 md:px-10 py-6 text-sm font-bold text-slate-600">
                      {new Date(item.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </td>
                    <td className="px-6 md:px-10 py-6">
                      <div className="flex items-center gap-2 text-sm font-bold text-emerald-600">
                        <Clock className="w-4 h-4" />
                        {item.verified_at ? new Date(item.verified_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                      </div>
                    </td>
                    <td className="px-6 md:px-10 py-6">
                      <div className="flex items-center gap-2 text-sm font-bold text-rose-600">
                        <Clock className="w-4 h-4" />
                        {item.checkout_at ? new Date(item.checkout_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                      </div>
                    </td>
                    <td className="px-6 md:px-10 py-6">
                      <span className={cn(
                        "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest",
                        item.status === 'completed' ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                      )}>
                        {item.status}
                      </span>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={6} className="px-6 md:px-10 py-12 text-center text-slate-400 font-bold">
                      No history recorded yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </motion.div>

      {/* Print All Labels Modal */}
      <Modal isOpen={isPrintAllModalOpen} onClose={() => setIsPrintAllModalOpen(false)} title="All Seat Labels">
        <div className="space-y-8">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 max-h-[60vh] overflow-y-auto p-4 bg-slate-50 rounded-[2rem]">
            {seats.map(seat => (
              <div key={seat.id} className="bg-white p-4 rounded-2xl border border-slate-100 flex flex-col items-center gap-3 shadow-sm">
                <QRCodeSVG value={seat.id} size={80} />
                <div className="text-center">
                  <p className="text-[10px] font-black text-slate-900">{seat.number}</p>
                  <p className="text-[8px] text-slate-400 font-bold uppercase tracking-widest">Floor {seat.floor}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-3">
            <Button className="flex-1 h-12 rounded-xl" onClick={() => window.print()}>
              <Download className="w-4 h-4 mr-2" />
              Print All Labels
            </Button>
            <Button variant="outline" className="flex-1 h-12 rounded-xl" onClick={() => setIsPrintAllModalOpen(false)}>
              Close
            </Button>
          </div>
        </div>
      </Modal>

      {/* QR View Modal */}
      <Modal isOpen={!!viewingQR} onClose={() => setViewingQR(null)} title={`Seat QR: ${viewingQR?.number}`}>
        <div className="space-y-8 text-center">
          <div className="p-8 bg-white border-2 border-slate-100 rounded-[2.5rem] shadow-sm flex justify-center mx-auto w-fit">
            <QRCodeSVG value={viewingQR?.id || ''} size={200} />
          </div>
          
          <div className="space-y-2">
            <p className="text-sm font-black text-slate-900">Physical Label for {viewingQR?.number}</p>
            <p className="text-xs text-slate-500 font-medium">Print this QR and place it on the corresponding desk.</p>
            <div className="mt-4 p-3 bg-slate-50 rounded-xl flex items-center justify-between gap-4">
              <code className="text-[10px] font-mono text-slate-500 truncate">{viewingQR?.id}</code>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 px-3 text-[10px] font-black uppercase tracking-widest rounded-lg bg-white shadow-sm hover:bg-indigo-50 hover:text-indigo-600"
                onClick={() => {
                  navigator.clipboard.writeText(viewingQR?.id || '');
                  toast.success('Seat ID copied to clipboard');
                }}
              >
                Copy ID
              </Button>
            </div>
          </div>

          <div className="flex gap-3">
            <Button className="flex-1 h-12 rounded-xl" onClick={() => window.print()}>
              <Download className="w-4 h-4 mr-2" />
              Print Label
            </Button>
            <Button variant="outline" className="flex-1 h-12 rounded-xl" onClick={() => setViewingQR(null)}>
              Close
            </Button>
          </div>
        </div>
      </Modal>

      {/* Add Seat Modal */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Register New Library Seat">
        <div className="space-y-6">
          <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-center gap-4">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-indigo-600 shadow-sm">
              <Plus className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-black text-indigo-900">New Seat Registration</p>
              <p className="text-xs text-indigo-600 font-medium">Configure the seat details below</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Seat Number</label>
              <Input 
                placeholder="e.g. A-101" 
                className="h-12 rounded-xl bg-slate-50 border-none font-bold focus:ring-2 focus:ring-indigo-500"
                value={newSeatNumber} 
                onChange={(e) => setNewSeatNumber(e.target.value)} 
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Floor Level</label>
                <select 
                  className="flex h-12 w-full rounded-xl border-none bg-slate-50 px-4 py-2 text-sm font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
                  value={newSeatFloor}
                  onChange={(e) => setNewSeatFloor(e.target.value)}
                >
                  <option value="1">Floor 1</option>
                  <option value="2">Floor 2</option>
                  <option value="3">Floor 3</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Seat Type</label>
                <select 
                  className="flex h-12 w-full rounded-xl border-none bg-slate-50 px-4 py-2 text-sm font-bold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
                  value={newSeatType}
                  onChange={(e: any) => setNewSeatType(e.target.value)}
                >
                  <option value="standard">Standard</option>
                  <option value="window">Window</option>
                  <option value="aisle">Aisle</option>
                </select>
              </div>
            </div>
          </div>
          <Button className="w-full h-12 rounded-xl text-sm font-black shadow-xl shadow-indigo-100" onClick={handleAddSeat}>
            Confirm Registration
          </Button>
        </div>
      </Modal>

      <ConfirmModal 
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={() => confirmDelete && handleRemoveSeat(confirmDelete)}
        title="Remove Seat"
        message="Are you sure you want to remove this seat? This action cannot be undone."
      />

      <ConfirmModal 
        isOpen={!!confirmRelease}
        onClose={() => setConfirmRelease(null)}
        onConfirm={() => confirmRelease && handleForceRelease(confirmRelease)}
        title="Force Release Seat"
        message="Are you sure you want to manually release this seat? This will terminate any active session."
      />
    </div>
  );
}

function StatCard({ icon, label, value, color, trend }: { icon: React.ReactNode; label: string; value: number; color: string; trend?: string }) {
  return (
    <Card className="p-8 border-none shadow-xl shadow-slate-200/30 bg-white group hover:shadow-2xl transition-all">
      <div className="flex items-start justify-between">
        <div className={cn("p-4 rounded-2xl shadow-sm transition-transform group-hover:scale-110", color)}>
          {icon}
        </div>
        {trend && (
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{trend}</span>
        )}
      </div>
      <div className="mt-6">
        <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">{label}</p>
        <p className="text-4xl font-black text-slate-900 mt-1">{value}</p>
      </div>
    </Card>
  );
}
