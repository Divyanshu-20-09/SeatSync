import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Button, Card, Input } from '../components/UI';
import { UserPlus, Library, GraduationCap, ShieldCheck, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function SignUpPage() {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState<'role' | 'form'>('role');
  const [role, setRole] = useState<'student' | 'admin'>('student');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [registrationNo, setRegistrationNo] = useState('');
  const [adminId, setAdminId] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault();
    
    // Validation: Admin ID must start with EMP
    if (role === 'admin' && !adminId.toUpperCase().startsWith('EMP')) {
      toast.error('Admin ID must start with "EMP" (e.g., EMP123)');
      return;
    }

    setLoading(true);

    const metadata = {
      full_name: fullName,
      role: role,
      registration_no: role === 'student' ? registrationNo : undefined,
      admin_id: role === 'admin' ? adminId : undefined,
    };

    const { error } = await signUp(email, password, metadata);
    
    if (error) {
      toast.error(error.message || 'Sign up failed');
    } else {
      toast.success('Account created! Please sign in.');
      navigate('/login');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-white flex overflow-hidden">
      {/* Left Pane - Branding & Info (Hidden on mobile) */}
      <div className="hidden lg:flex lg:w-1/2 bg-slate-900 relative p-16 flex-col justify-between overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full -z-0">
          <div className="absolute top-[-20%] left-[-20%] w-[80%] h-[80%] bg-indigo-500/20 rounded-full blur-[120px] animate-pulse" />
          <div className="absolute bottom-[-20%] right-[-20%] w-[80%] h-[80%] bg-blue-500/20 rounded-full blur-[120px] animate-pulse delay-700" />
        </div>

        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="relative z-10 flex items-center gap-4"
        >
          <Link to="/" className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-indigo-500/50">
              <Library className="w-7 h-7 text-white" />
            </div>
            <span className="text-2xl font-black text-white tracking-tighter uppercase">SeatSync</span>
          </Link>
        </motion.div>

        <div className="relative z-10 space-y-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-7xl font-black text-white leading-[0.9] tracking-tighter"
          >
            JOIN THE <br />
            FUTURE OF <br />
            <span className="text-indigo-500">STUDY.</span>
          </motion.h1>
          <p className="text-slate-400 text-xl font-medium max-w-md leading-relaxed">
            Create your account and start managing your study sessions with precision.
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-8">
          <div className="space-y-1">
            <p className="text-4xl font-black text-white">100%</p>
            <p className="text-xs font-black text-slate-500 uppercase tracking-widest">Digital Flow</p>
          </div>
          <div className="w-[1px] h-12 bg-slate-800" />
          <div className="space-y-1">
            <p className="text-4xl font-black text-white">Fast</p>
            <p className="text-xs font-black text-slate-500 uppercase tracking-widest">Onboarding</p>
          </div>
        </div>
      </div>

      {/* Right Pane - Auth Form */}
      <div className="w-full lg:w-1/2 flex flex-col items-center justify-center p-6 md:p-16 bg-slate-50/50 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md space-y-8 py-8"
        >
          <div className="space-y-2">
            <div className="lg:hidden flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
                <Library className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-black text-slate-900 tracking-tighter uppercase">SeatSync</span>
            </div>
            
            <AnimatePresence mode="wait">
              {step === 'role' ? (
                <motion.div
                  key="role-header"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-2"
                >
                  <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight">Who are you?</h2>
                  <p className="text-sm md:text-base text-slate-500 font-medium">Select your role to continue registration</p>
                </motion.div>
              ) : (
                <motion.div
                  key="form-header"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-2"
                >
                  <button 
                    onClick={() => setStep('role')}
                    className="flex items-center gap-2 text-indigo-600 font-black text-[10px] uppercase tracking-widest mb-4 hover:gap-3 transition-all"
                  >
                    <ArrowLeft className="w-3 h-3" />
                    Back to role selection
                  </button>
                  <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight">
                    {role === 'student' ? 'Student' : 'Admin'} Sign Up
                  </h2>
                  <p className="text-sm md:text-base text-slate-500 font-medium">Please provide your details below</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <AnimatePresence mode="wait">
            {step === 'role' ? (
              <motion.div
                key="role-selection"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="grid grid-cols-1 gap-4"
              >
                <button
                  onClick={() => { setRole('student'); setStep('form'); }}
                  className="group p-8 bg-white border-2 border-slate-100 rounded-[2rem] text-left hover:border-indigo-600 hover:shadow-2xl hover:shadow-indigo-100 transition-all"
                >
                  <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <GraduationCap className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-black text-slate-900">I am a Student</h3>
                  <p className="text-sm text-slate-500 font-medium mt-1">Book seats, scan QRs, and manage your study time.</p>
                </button>

                <button
                  onClick={() => { setRole('admin'); setStep('form'); }}
                  className="group p-8 bg-white border-2 border-slate-100 rounded-[2rem] text-left hover:border-slate-900 hover:shadow-2xl hover:shadow-slate-200 transition-all"
                >
                  <div className="w-14 h-14 bg-slate-100 text-slate-900 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <ShieldCheck className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-black text-slate-900">I am an Admin</h3>
                  <p className="text-sm text-slate-500 font-medium mt-1">Manage seats, monitor activity, and oversee the library.</p>
                </button>
              </motion.div>
            ) : (
              <motion.form
                key="signup-form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleSignUp}
                className="space-y-5"
              >
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Full Name</label>
                  <Input 
                    placeholder="John Doe" 
                    className="h-14 rounded-2xl bg-white border-slate-200 font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                    value={fullName} 
                    onChange={(e) => setFullName(e.target.value)} 
                    required 
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Email Address</label>
                  <Input 
                    type="email" 
                    placeholder="name@university.edu" 
                    className="h-14 rounded-2xl bg-white border-slate-200 font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                    required 
                  />
                </div>

                {role === 'student' ? (
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Registration Number</label>
                    <Input 
                      placeholder="e.g. 24BCE1868" 
                      className="h-14 rounded-2xl bg-white border-slate-200 font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                      value={registrationNo} 
                      onChange={(e) => setRegistrationNo(e.target.value)} 
                      required 
                    />
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Admin ID (Must start with EMP)</label>
                    <Input 
                      placeholder="e.g. EMP-2026-001" 
                      className="h-14 rounded-2xl bg-white border-slate-200 font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                      value={adminId} 
                      onChange={(e) => setAdminId(e.target.value.toUpperCase())} 
                      required 
                    />
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Set Password</label>
                  <Input 
                    type="password" 
                    placeholder="••••••••" 
                    className="h-14 rounded-2xl bg-white border-slate-200 font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                    value={password} 
                    onChange={(e) => setPassword(e.target.value)} 
                    required 
                  />
                </div>

                <div className="pt-4">
                  <Button type="submit" className="w-full h-14 rounded-2xl text-sm font-black shadow-xl shadow-indigo-100" isLoading={loading}>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Complete Registration
                  </Button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="text-center">
            <Link 
              to="/login"
              className="text-sm text-slate-500 font-bold hover:text-indigo-600 transition-colors"
            >
              Already have an account? <span className="text-indigo-600 underline underline-offset-4">Sign in here</span>
            </Link>
          </div>
        </motion.div>

        <p className="mt-auto pt-8 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
          &copy; 2026 SeatSync Library Systems
        </p>
      </div>
    </div>
  );
}
