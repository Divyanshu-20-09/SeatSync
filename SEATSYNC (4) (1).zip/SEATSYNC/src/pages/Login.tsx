import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Button, Card, Input } from '../components/UI';
import { LogIn, Library, ShieldCheck, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

export default function LoginPage() {
  const { login } = useAuth();
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    const { error } = await login(userId, password);
    if (error) {
      toast.error(error.message || 'Login failed');
    } else {
      toast.success('Welcome back!');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-white flex overflow-hidden">
      {/* Left Pane - Branding & Info */}
      <div className="hidden lg:flex lg:w-1/2 bg-slate-900 relative p-16 flex-col justify-between overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full -z-0">
          <div className="absolute top-[-20%] left-[-20%] w-[80%] h-[80%] bg-indigo-500/20 rounded-full blur-[120px] animate-pulse" />
          <div className="absolute bottom-[-20%] right-[-20%] w-[80%] h-[80%] bg-blue-500/20 rounded-full blur-[120px] animate-pulse delay-700" />
        </div>

        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="relative z-10 flex items-center gap-4"
        >
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-indigo-500/50">
            <Library className="w-7 h-7 text-white" />
          </div>
          <span className="text-2xl font-black text-white tracking-tighter uppercase">SeatSync</span>
        </motion.div>

        <div className="relative z-10 space-y-8">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-7xl font-black text-white leading-[0.9] tracking-tighter"
          >
            RESERVE <br />
            YOUR <br />
            <span className="text-indigo-500">FOCUS.</span>
          </motion.h1>
          <p className="text-slate-400 text-xl font-medium max-w-md leading-relaxed">
            The modern library seat allocation system designed for maximum productivity.
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-8">
          <div className="space-y-1">
            <p className="text-4xl font-black text-white">2.4k+</p>
            <p className="text-xs font-black text-slate-500 uppercase tracking-widest">Active Students</p>
          </div>
          <div className="w-[1px] h-12 bg-slate-800" />
          <div className="space-y-1">
            <p className="text-4xl font-black text-white">98%</p>
            <p className="text-xs font-black text-slate-500 uppercase tracking-widest">Satisfaction</p>
          </div>
        </div>
      </div>

      {/* Right Pane - Login Form */}
      <div className="w-full lg:w-1/2 flex flex-col items-center justify-center p-6 md:p-16 bg-slate-50/50 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md space-y-8 md:space-y-10 py-8"
        >
          <div className="space-y-2">
            <div className="lg:hidden flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
                <Library className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-black text-slate-900 tracking-tighter uppercase">SeatSync</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight">Welcome back</h2>
            <p className="text-sm md:text-base text-slate-500 font-medium">Enter your credentials to access your dashboard</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">User ID (Reg No / Admin ID)</label>
              <Input 
                type="text" 
                placeholder="Enter your Registration No or Admin ID" 
                className="h-14 rounded-2xl bg-white border-slate-200 font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                value={userId} 
                onChange={(e) => setUserId(e.target.value)} 
                required 
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Password</label>
                <button type="button" className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline">
                  Forgot?
                </button>
              </div>
              <Input 
                type="password" 
                placeholder="••••••••" 
                className="h-14 rounded-2xl bg-white border-slate-200 font-bold focus:ring-2 focus:ring-indigo-500 transition-all"
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
              />
            </div>

            <div className="pt-4 space-y-4">
              <Button type="submit" className="w-full h-14 rounded-2xl text-sm font-black shadow-xl shadow-indigo-100" isLoading={loading}>
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-slate-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-slate-50 px-4 text-slate-400 font-black tracking-widest">New to SeatSync?</span>
                </div>
              </div>

              <Link to="/signup">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full h-14 rounded-2xl text-sm font-black border-slate-200 hover:bg-slate-900 hover:text-white transition-all" 
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Create New Account
                </Button>
              </Link>
            </div>
          </form>

          <p className="text-center text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">
            &copy; 2026 SeatSync Library Systems
          </p>
        </motion.div>
      </div>
    </div>
  );
}
