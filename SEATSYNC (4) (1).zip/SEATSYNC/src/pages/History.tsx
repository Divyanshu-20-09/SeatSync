import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { Card, Button } from '../components/UI';
import { History, Clock, CheckCircle2, Calendar, Search, Filter } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function HistoryPage() {
  const { profile } = useAuth();
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      if (!profile) return;
      
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('*, seats(*)')
          .eq('user_id', profile.id)
          .in('status', ['completed', 'cancelled'])
          .order('created_at', { ascending: false });

        if (error) throw error;
        setHistory(data || []);
      } catch (error) {
        console.error('Error fetching history:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, [profile]);

  const stats = {
    totalSessions: history.length,
    totalHours: history.reduce((acc, item) => {
      if (!item.verified_at || !item.checkout_at) return acc;
      const start = new Date(item.verified_at).getTime();
      const end = new Date(item.checkout_at).getTime();
      const hours = (end - start) / (1000 * 60 * 60);
      return acc + Math.max(0, hours);
    }, 0).toFixed(1),
    completionRate: history.length > 0 
      ? Math.round((history.filter(h => h.status === 'completed').length / history.length) * 100) 
      : 0
  };

  if (loading) return null;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Booking History</h1>
          <p className="text-slate-500 font-medium">Review your past study sessions and seat usage</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
            <input 
              type="text"
              placeholder="Search history..."
              className="pl-12 pr-4 h-12 w-64 bg-white border border-slate-100 rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 transition-all shadow-sm"
            />
          </div>
          <Button variant="outline" className="h-12 rounded-xl border-slate-200">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <Card className="p-6 border-none shadow-xl shadow-slate-200/40 rounded-[2rem] space-y-6">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Summary</h3>
            <div className="space-y-4">
              <SummaryItem label="Total Sessions" value={stats.totalSessions.toString()} icon={<History className="w-4 h-4" />} color="bg-indigo-50 text-indigo-600" />
              <SummaryItem label="Total Hours" value={`${stats.totalHours}h`} icon={<Clock className="w-4 h-4" />} color="bg-emerald-50 text-emerald-600" />
              <SummaryItem label="Completion Rate" value={`${stats.completionRate}%`} icon={<CheckCircle2 className="w-4 h-4" />} color="bg-blue-50 text-blue-600" />
            </div>
          </Card>

          <Card className="p-6 border-none shadow-xl shadow-slate-200/40 rounded-[2rem] bg-indigo-600 text-white overflow-hidden relative group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:bg-white/20 transition-colors" />
            <div className="relative z-10 space-y-4">
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                <Calendar className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <p className="text-xs font-black uppercase tracking-widest opacity-80">Next Session</p>
                <p className="text-lg font-black">Tomorrow, 10:00 AM</p>
              </div>
              <Button className="w-full bg-white text-indigo-600 hover:bg-slate-50 rounded-xl font-black text-xs uppercase tracking-widest">
                Set Reminder
              </Button>
            </div>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Card className="border-none shadow-xl shadow-slate-200/40 rounded-[2rem] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[600px]">
                <thead>
                  <tr className="bg-slate-50/50 text-slate-400 text-[10px] uppercase tracking-[0.2em] font-black">
                    <th className="px-8 py-5">Seat Info</th>
                    <th className="px-8 py-5">Date</th>
                    <th className="px-8 py-5">Check-in</th>
                    <th className="px-8 py-5">Check-out</th>
                    <th className="px-8 py-5">Status</th>
                    <th className="px-8 py-5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {history.length > 0 ? history.map((item, idx) => (
                    <motion.tr 
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="hover:bg-slate-50/30 transition-colors group"
                    >
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 font-black text-sm">
                            {item.seats?.number?.split('-')[1] || '?'}
                          </div>
                          <div>
                            <p className="font-black text-slate-900">{item.seats?.number || 'Unknown'}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Floor {item.seats?.floor} • {item.seats?.type}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          {new Date(item.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                          <Clock className="w-4 h-4 text-emerald-400" />
                          {item.verified_at ? new Date(item.verified_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center gap-2 text-sm font-bold text-slate-600">
                          <Clock className="w-4 h-4 text-rose-400" />
                          {item.checkout_at ? new Date(item.checkout_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <span className={cn(
                          "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest",
                          item.status === 'completed' ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                        )}>
                          <div className={cn(
                            "w-1.5 h-1.5 rounded-full",
                            item.status === 'completed' ? "bg-emerald-500" : "bg-rose-500"
                          )} />
                          {item.status}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <Button variant="ghost" size="sm" className="h-9 px-4 text-[10px] font-black uppercase tracking-widest rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-indigo-50">
                          Details
                        </Button>
                      </td>
                    </motion.tr>
                  )) : (
                    <tr>
                      <td colSpan={5} className="px-8 py-20 text-center">
                        <div className="flex flex-col items-center gap-4">
                          <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                            <History className="w-8 h-8 text-slate-300" />
                          </div>
                          <p className="text-slate-400 font-bold">No booking history available yet.</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function SummaryItem({ label, value, icon, color }: { label: string; value: string; icon: React.ReactNode; color: string }) {
  return (
    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
      <div className="flex items-center gap-3">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shadow-sm", color)}>
          {icon}
        </div>
        <span className="text-xs font-bold text-slate-500">{label}</span>
      </div>
      <span className="text-sm font-black text-slate-900">{value}</span>
    </div>
  );
}
