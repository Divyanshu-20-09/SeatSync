import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Card, Button } from '../components/UI';
import { User, Mail, Shield, Hash, Calendar, Edit2, LogOut } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';

export default function ProfilePage() {
  const { profile, logout } = useAuth();

  if (!profile) return null;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">My Profile</h1>
          <p className="text-slate-500 font-medium">Manage your account settings and preferences</p>
        </div>
        <Button variant="outline" className="rounded-xl border-slate-200" onClick={() => toast.info('Edit profile coming soon!')}>
          <Edit2 className="w-4 h-4 mr-2" />
          Edit Profile
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="md:col-span-1 p-8 flex flex-col items-center text-center space-y-6 border-none shadow-xl shadow-slate-200/40 rounded-[2.5rem]">
          <div className="w-32 h-32 rounded-[2.5rem] bg-indigo-600 flex items-center justify-center text-white text-5xl font-black shadow-2xl shadow-indigo-200">
            {profile.full_name.charAt(0)}
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-black text-slate-900">{profile.full_name}</h2>
            <p className="text-xs font-black text-indigo-600 uppercase tracking-widest">
              {profile.role} • {profile.role === 'student' ? profile.registration_no : profile.admin_id}
            </p>
          </div>
          <Button 
            variant="danger" 
            className="w-full rounded-xl" 
            onClick={() => {
              logout();
              toast.success('Signed out successfully');
            }}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </Card>

        <Card className="md:col-span-2 p-8 border-none shadow-xl shadow-slate-200/40 rounded-[2.5rem] space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            <InfoItem 
              icon={<User className="w-5 h-5 text-indigo-600" />} 
              label="Full Name" 
              value={profile.full_name} 
            />
            <InfoItem 
              icon={<Mail className="w-5 h-5 text-indigo-600" />} 
              label="Email Address" 
              value={profile.email} 
            />
            <InfoItem 
              icon={<Shield className="w-5 h-5 text-indigo-600" />} 
              label="Account Role" 
              value={profile.role.charAt(0).toUpperCase() + profile.role.slice(1)} 
            />
            <InfoItem 
              icon={<Hash className="w-5 h-5 text-indigo-600" />} 
              label={profile.role === 'student' ? 'Registration No' : 'Admin ID'} 
              value={profile.role === 'student' ? profile.registration_no || 'N/A' : profile.admin_id || 'N/A'} 
            />
            <InfoItem 
              icon={<Calendar className="w-5 h-5 text-indigo-600" />} 
              label="Joined On" 
              value={new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })} 
            />
          </div>

          <div className="pt-8 border-t border-slate-50">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest mb-4">Security Settings</h3>
            <div className="space-y-4">
              <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-colors group">
                <span className="text-sm font-bold text-slate-700">Change Password</span>
                <Edit2 className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
              </button>
              <button className="w-full flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-colors group">
                <span className="text-sm font-bold text-slate-700">Two-Factor Authentication</span>
                <div className="w-10 h-5 bg-slate-200 rounded-full relative">
                  <div className="absolute left-1 top-1 w-3 h-3 bg-white rounded-full" />
                </div>
              </button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

function InfoItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-4">
      <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0">
        {icon}
      </div>
      <div className="space-y-0.5">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
        <p className="text-sm font-bold text-slate-900">{value}</p>
      </div>
    </div>
  );
}
