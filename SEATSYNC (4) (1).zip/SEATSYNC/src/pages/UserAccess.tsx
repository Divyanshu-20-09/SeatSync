import React, { useState, useEffect } from 'react';
import { Card, Button } from '../components/UI';
import { Users, User, Shield, Mail, Search, Filter, MoreVertical, Trash2, Edit2, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { toast } from 'sonner';
import { supabase } from '../lib/supabase';
import type { Profile } from '../types';

export default function UserAccessPage() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchProfiles = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProfiles(data || []);
    } catch (error: any) {
      console.error('Error fetching profiles:', error);
      toast.error(error.message || 'Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfiles();
  }, []);

  const filteredProfiles = profiles.filter(p => 
    p.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.registration_no?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.admin_id?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">User Access Management</h1>
          <p className="text-slate-500 font-medium">Manage user accounts, roles, and permissions</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
            <input 
              type="text"
              placeholder="Search users..."
              className="pl-12 pr-4 h-12 w-64 bg-white border border-slate-100 rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 transition-all shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button className="h-12 rounded-xl shadow-xl shadow-indigo-100" onClick={fetchProfiles}>
            <Users className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <Card className="p-6 border-none shadow-xl shadow-slate-200/40 rounded-[2rem] space-y-6">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">User Stats</h3>
            <div className="space-y-4">
              <StatItem label="Total Users" value={profiles.length} icon={<Users className="w-4 h-4" />} color="bg-indigo-50 text-indigo-600" />
              <StatItem label="Admins" value={profiles.filter((p: any) => p.role === 'admin').length} icon={<Shield className="w-4 h-4" />} color="bg-emerald-50 text-emerald-600" />
              <StatItem label="Students" value={profiles.filter((p: any) => p.role === 'student').length} icon={<User className="w-4 h-4" />} color="bg-blue-50 text-blue-600" />
            </div>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Card className="border-none shadow-xl shadow-slate-200/40 rounded-[2rem] overflow-hidden">
            <div className="overflow-x-auto">
              {loading ? (
                <div className="p-20 flex flex-col items-center justify-center gap-4">
                  <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
                  <p className="text-slate-500 font-bold">Loading users...</p>
                </div>
              ) : (
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead>
                    <tr className="bg-slate-50/50 text-slate-400 text-[10px] uppercase tracking-[0.2em] font-black">
                      <th className="px-8 py-5">User Info</th>
                      <th className="px-8 py-5">ID / Reg No</th>
                      <th className="px-8 py-5">Role</th>
                      <th className="px-8 py-5">Joined</th>
                      <th className="px-8 py-5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredProfiles.length > 0 ? filteredProfiles.map((user: any, idx: number) => (
                      <motion.tr 
                        key={user.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        className="hover:bg-slate-50/30 transition-colors group"
                      >
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-black text-sm">
                              {user.full_name?.charAt(0)}
                            </div>
                            <div>
                              <p className="font-black text-slate-900">{user.full_name}</p>
                              <div className="flex items-center gap-1 text-[10px] text-slate-400 font-bold">
                                <Mail className="w-3 h-3" />
                                {user.email}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <span className="text-sm font-bold text-slate-600">
                            {user.role === 'student' ? user.registration_no : user.admin_id}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          <span className={cn(
                            "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest",
                            user.role === 'admin' ? "bg-indigo-50 text-indigo-600" : "bg-blue-50 text-blue-600"
                          )}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          <span className="text-xs font-bold text-slate-400">
                            {new Date(user.created_at).toLocaleDateString()}
                          </span>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-9 w-9 p-0 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-indigo-50"
                              onClick={() => toast.info('Edit user coming soon!')}
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-9 w-9 p-0 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                              onClick={() => toast.error('Delete user coming soon!')}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </motion.tr>
                    )) : (
                      <tr>
                        <td colSpan={5} className="px-8 py-20 text-center text-slate-400 font-bold">
                          No users found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatItem({ label, value, icon, color }: { label: string; value: number; icon: React.ReactNode; color: string }) {
  return (
    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
      <div className="flex items-center gap-3">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shadow-sm", color)}>
          {icon}
        </div>
        <span className="text-xs font-bold text-slate-500">{label}</span>
      </div>
      <span className="text-sm font-black text-slate-900">{value}</span>
    </div>
  );
}
