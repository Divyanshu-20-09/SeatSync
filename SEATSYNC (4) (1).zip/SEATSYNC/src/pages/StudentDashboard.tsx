import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSeats, useActiveBooking } from '../hooks/useSeats';
import { Button, Card, Modal, Input, ConfirmModal } from '../components/UI';
import { QRScanner } from '../components/QRScanner';
import { cn } from '../lib/utils';
import { 
  Search, 
  Filter, 
  Clock, 
  QrCode, 
  CheckCircle2, 
  AlertCircle,
  Activity,
  RefreshCcw,
  LogOut,
  XCircle,
  Camera,
  Upload,
  TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';
import { QRCodeSVG } from 'qrcode.react';
import { formatDistanceToNow, isAfter, parseISO } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip 
} from 'recharts';

export default function StudentDashboard() {
  const { profile } = useAuth();
  const { seats, loading: seatsLoading, updateSeatStatus } = useSeats();
  const { 
    booking, 
    loading: bookingLoading, 
    createBooking, 
    verifyOTP, 
    clearBooking 
  } = useActiveBooking(profile?.id);
  
  const [selectedFloor, setSelectedFloor] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSeat, setSelectedSeat] = useState<any>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [isQRScannerOpen, setIsQRScannerOpen] = useState(false);
  const [isConfirmReleaseOpen, setIsConfirmReleaseOpen] = useState(false);
  const [otpInput, setOtpInput] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [otpShown, setOtpShown] = useState(false);

  const stats = {
    total: seats.length,
    available: seats.filter(s => s.status === 'available').length,
    occupied: seats.filter(s => s.status === 'occupied').length,
    reserved: seats.filter(s => s.status === 'reserved').length,
  };

  const occupancyRate = Math.round((stats.occupied / (stats.total || 1)) * 100);

  // Reset otpShown when booking changes or is cleared
  useEffect(() => {
    if (!booking || booking.status !== 'pending') {
      setOtpShown(false);
    }
  }, [booking?.id, booking?.status]);

  // Auto-open OTP modal only once per pending booking
  useEffect(() => {
    if (booking?.status === 'pending' && !otpShown && !isBookingModalOpen) {
      setIsBookingModalOpen(true);
      setOtpShown(true);
    }
  }, [booking?.status, otpShown, isBookingModalOpen]);

  // Timer logic
  useEffect(() => {
    if (!booking || !booking.expires_at || booking.status === 'completed' || booking.status === 'cancelled') {
      setTimeLeft('');
      return;
    }

    let isClearing = false;

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const expiry = new Date(booking.expires_at).getTime();
      const diff = expiry - now;

      // Add a 10-second grace period to handle clock skew
      if (diff <= -10000 && !isClearing) {
        isClearing = true;
        if (booking.status === 'pending') {
          clearBooking('cancelled').then(() => {
            toast.error('Reservation expired');
          }).catch(() => {
            isClearing = false;
          });
        } else if (booking.status === 'active') {
          clearBooking('completed').then(() => {
            toast.info('Session ended automatically');
          }).catch(() => {
            isClearing = false;
          });
        }
        clearInterval(timer);
        return;
      }

      const displayDiff = Math.max(0, diff);
      const minutes = Math.floor(displayDiff / 60000);
      const seconds = Math.floor((displayDiff % 60000) / 1000);
      setTimeLeft(`${minutes}:${seconds.toString().padStart(2, '0')}`);
    }, 1000);

    return () => clearInterval(timer);
  }, [booking, clearBooking]);

  const handleQRScan = async (data: string) => {
    const scannedSeat = seats.find(s => s.id === data || s.number === data);
    if (!scannedSeat) {
      toast.error('Invalid QR Code. Please scan a valid seat QR.');
      return;
    }

    if (scannedSeat.status !== 'available' && (!booking || booking.seat_id !== scannedSeat.id)) {
      toast.error('This seat is already occupied or reserved.');
      return;
    }

    try {
      if (!booking) {
        // Step 1 & 2: Create booking and generate OTP in one go
        await createBooking(scannedSeat);
        toast.success(`QR Scanned! OTP generated for seat ${scannedSeat.number}.`);
        setOtpShown(true);
        setIsBookingModalOpen(true);
      } else if (booking.seat_id === scannedSeat.id) {
        // Just open the modal if already booked, don't regenerate OTP unnecessarily
        setIsBookingModalOpen(true);
        setOtpShown(true);
      } else {
        toast.error('You already have a booking for a different seat.');
        setIsQRScannerOpen(false);
        return;
      }
      
      setIsQRScannerOpen(false);
      setIsBookingModalOpen(true);
    } catch (error: any) {
      toast.error(error.message || 'Failed to process QR scan');
    }
  };

  async function handleVerifyOTP() {
    if (!booking) return;
    setIsVerifying(true);

    try {
      const success = await verifyOTP(otpInput.trim());
      if (success) {
        toast.success('Session activated! Happy studying.');
        setOtpInput('');
        setIsBookingModalOpen(false);
      }
    } catch (error: any) {
      console.error('Verification error:', error);
    } finally {
      setIsVerifying(false);
    }
  }

  async function handleCheckout() {
    if (!booking) return;
    await clearBooking('completed');
    toast.success('Checked out successfully');
  }

  async function handleCancelBooking() {
    if (!booking) {
      setIsBookingModalOpen(false);
      return;
    }
    
    // Close modal immediately for better UX
    setIsBookingModalOpen(false);
    
    try {
      await clearBooking('cancelled');
      toast.info('Booking cancelled');
    } catch (error: any) {
      console.error('Cancellation error:', error);
      toast.error(`Failed to cancel: ${error.message || 'Please try again'}`);
    }
  }

  if (seatsLoading || bookingLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const filteredSeats = seats.filter(seat => 
    seat.floor === selectedFloor && 
    (searchQuery === '' || seat.number.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6 md:space-y-8 pb-20 px-4 md:px-0">
      {/* Header with Glassmorphism */}
      <div className="relative p-6 md:p-8 rounded-[1.5rem] md:rounded-[2.5rem] bg-white border border-slate-100 shadow-2xl shadow-slate-200/50 overflow-hidden group">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full -mr-32 -mt-32 blur-3xl group-hover:bg-indigo-500/10 transition-colors" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/5 rounded-full -ml-32 -mb-32 blur-3xl group-hover:bg-blue-500/10 transition-colors" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6 md:gap-8">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest">
              <Activity className="w-3 h-3 animate-pulse" />
              Live Availability
            </div>
            <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight">
              Welcome back, <span className="text-indigo-600">{(profile?.full_name && profile.full_name.length > 1) ? profile.full_name.split(' ')[0] : 'Student'}</span>
            </h1>
            <p className="text-slate-500 text-sm md:text-base font-medium max-w-md">
              The library is currently <span className={cn(
                "font-bold",
                occupancyRate > 80 ? "text-rose-600" : occupancyRate > 50 ? "text-amber-600" : "text-green-600"
              )}>{occupancyRate}% occupied</span>. Find your perfect spot for focused study.
            </p>
          </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <Button 
                onClick={() => setIsQRScannerOpen(true)}
                className="h-12 md:h-14 px-6 md:px-8 rounded-xl md:rounded-2xl bg-slate-900 text-white shadow-xl shadow-slate-200 hover:bg-slate-800"
              >
                <QrCode className="w-5 h-5 mr-2" />
                Scan to Book
              </Button>
              <div className="relative group/search">
                <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within/search:text-indigo-600 transition-colors" />
                <input 
                  type="text"
                  placeholder="Search seat number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-4 h-12 md:h-14 w-full sm:w-72 bg-slate-50 border-none rounded-xl md:rounded-2xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 transition-all shadow-inner"
                />
              </div>
            </div>
        </div>
      </div>

      {/* Stats & Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="p-6 border-none shadow-xl shadow-slate-200/30 bg-white rounded-[2rem]">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Available</p>
              <p className="text-3xl font-black text-emerald-600">{stats.available}</p>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="p-6 border-none shadow-xl shadow-slate-200/30 bg-white rounded-[2rem]">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Occupied</p>
              <p className="text-3xl font-black text-rose-600">{stats.occupied}</p>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Card className="p-6 border-none shadow-xl shadow-slate-200/30 bg-white rounded-[2rem]">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Reserved</p>
              <p className="text-3xl font-black text-amber-600">{stats.reserved}</p>
            </Card>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-1"
        >
          <Card className="p-6 border-none shadow-xl shadow-slate-200/30 bg-white rounded-[2rem] flex items-center gap-6">
            <div className="w-24 h-24 flex-shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: 'Available', value: stats.available },
                      { name: 'Occupied', value: stats.occupied },
                      { name: 'Reserved', value: stats.reserved },
                    ]}
                    cx="50%"
                    cy="50%"
                    innerRadius={25}
                    outerRadius={35}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    <Cell fill="#10b981" />
                    <Cell fill="#f43f5e" />
                    <Cell fill="#f59e0b" />
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-2 mb-2">
                <TrendingUp className="w-3 h-3 text-indigo-600" />
                Live Load
              </h4>
              <p className="text-2xl font-black text-slate-900">
                {Math.round((stats.occupied / (stats.total || 1)) * 100)}%
              </p>
              <p className="text-[10px] font-bold text-slate-400 uppercase">Occupancy Rate</p>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Active Session Banner */}
      <AnimatePresence>
        {booking && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
          >
            <div className={cn(
              "p-0.5 md:p-1 rounded-[1.5rem] md:rounded-[2rem] shadow-2xl transition-all",
              booking.status === 'pending' 
                ? "bg-gradient-to-r from-yellow-400 to-orange-400 shadow-orange-200/50" 
                : "bg-gradient-to-r from-indigo-600 to-blue-600 shadow-indigo-200/50"
            )}>
              <div className="bg-white/95 backdrop-blur-md rounded-[1.4rem] md:rounded-[1.8rem] p-4 md:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6 md:gap-8">
                <div className="flex items-center gap-4 md:gap-6">
                  <div className={cn(
                    "w-12 h-12 md:w-16 md:h-16 rounded-xl md:rounded-2xl flex items-center justify-center shadow-lg",
                    booking.status === 'pending' 
                      ? "bg-yellow-100 text-yellow-600 shadow-yellow-100" 
                      : "bg-indigo-100 text-indigo-600 shadow-indigo-100"
                  )}>
                    {booking.status === 'pending' ? <QrCode className="w-6 h-6 md:w-8 md:h-8" /> : <Clock className="w-6 h-6 md:w-8 md:h-8" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg md:text-xl font-black text-slate-900">
                        {booking.status === 'pending' ? 'Verification Required' : 'Session in Progress'}
                      </h3>
                      <span className={cn(
                        "px-2 py-0.5 rounded-md text-[8px] md:text-[10px] font-black uppercase tracking-wider",
                        booking.status === 'pending' ? "bg-yellow-100 text-yellow-700" : "bg-green-100 text-green-700"
                      )}>
                        {booking.status}
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-slate-500 font-bold">
                      Seat <span className="text-indigo-600">{booking.seats?.number}</span> • <span className="capitalize">{booking.seats?.type}</span> • Floor {booking.seats?.floor}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center gap-6 md:gap-8 lg:gap-12">
                  <div className="flex items-center gap-8 md:gap-12">
                    {booking.status === 'pending' && booking.otp && (
                      <div className="space-y-1">
                        <p className="text-[8px] md:text-[10px] text-amber-600 uppercase font-black tracking-[0.2em]">Your OTP Code</p>
                        <p className="text-2xl md:text-3xl font-black text-amber-600 font-mono tracking-[0.2em]">{booking.otp}</p>
                      </div>
                    )}

                    {timeLeft && (
                      <div className="space-y-1">
                        <p className="text-[8px] md:text-[10px] text-slate-400 uppercase font-black tracking-[0.2em]">
                          {booking.status === 'pending' ? 'Verification Ends In' : 'Session Ends In'}
                        </p>
                        <p className="text-2xl md:text-3xl font-black text-slate-900 font-mono tabular-nums">{timeLeft}</p>
                      </div>
                    )}

                    {booking.status === 'active' && booking.verified_at && (
                      <div className="space-y-1">
                        <p className="text-[8px] md:text-[10px] text-slate-400 uppercase font-black tracking-[0.2em]">Check-in Time</p>
                        <p className="text-lg md:text-xl font-black text-indigo-600 font-mono">
                          {new Date(booking.verified_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    )}

                    {booking.status === 'pending' && !booking.otp && (
                      <div className="flex items-center gap-3 text-amber-600">
                        <QrCode className="w-5 h-5 animate-bounce" />
                        <p className="text-xs font-black uppercase tracking-widest">Scan QR at desk to start</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-3">
                    {booking.status === 'pending' ? (
                      <>
                        {booking.otp ? (
                          <Button 
                            onClick={() => setIsBookingModalOpen(true)}
                            className="flex-1 sm:flex-none h-12 md:h-14 px-6 md:px-8 rounded-xl md:rounded-2xl bg-amber-500 hover:bg-amber-600 text-white shadow-xl shadow-amber-100"
                          >
                            <CheckCircle2 className="w-5 h-5 mr-2" />
                            Enter OTP
                          </Button>
                        ) : (
                          <Button 
                            onClick={() => setIsQRScannerOpen(true)}
                            className="flex-1 sm:flex-none h-12 md:h-14 px-6 md:px-8 rounded-xl md:rounded-2xl bg-slate-900 text-white shadow-xl shadow-slate-200"
                          >
                            <Camera className="w-5 h-5 mr-2" />
                            Scan QR
                          </Button>
                        )}
                        <Button 
                          variant="outline"
                          onClick={handleCancelBooking}
                          className="h-12 md:h-14 px-4 md:px-6 rounded-xl md:rounded-2xl text-rose-600 border-rose-100 hover:bg-rose-50 hover:border-rose-200"
                        >
                          Cancel
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button variant="outline" className="flex-1 sm:flex-none h-12 md:h-14 px-4 md:px-6 rounded-xl md:rounded-2xl border-slate-200 hover:bg-slate-50">
                          <RefreshCcw className="w-5 h-5 mr-2" />
                          Extend
                        </Button>
                        <Button 
                          variant="danger" 
                          className="flex-1 sm:flex-none h-12 md:h-14 px-6 md:px-8 rounded-xl md:rounded-2xl shadow-xl shadow-red-100" 
                          onClick={() => setIsConfirmReleaseOpen(true)}
                        >
                          <LogOut className="w-5 h-5 mr-2" />
                          Release Seat
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* How it Works Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
        <div className="p-6 md:p-8 bg-white rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 space-y-4 group hover:shadow-2xl transition-all">
          <div className="w-10 h-10 md:w-12 md:h-12 bg-indigo-50 text-indigo-600 rounded-xl md:rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <Search className="w-5 h-5 md:w-6 md:h-6" />
          </div>
          <div className="space-y-1">
            <h4 className="font-black text-slate-900 text-sm md:text-base">1. Find a Spot</h4>
            <p className="text-[10px] md:text-xs text-slate-500 font-medium leading-relaxed">Browse the live map or search for specific seat numbers across all floors.</p>
          </div>
        </div>
        <div className="p-6 md:p-8 bg-white rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 space-y-4 group hover:shadow-2xl transition-all">
          <div className="w-10 h-10 md:w-12 md:h-12 bg-amber-50 text-amber-600 rounded-xl md:rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <QrCode className="w-5 h-5 md:w-6 md:h-6" />
          </div>
          <div className="space-y-1">
            <h4 className="font-black text-slate-900 text-sm md:text-base">2. Scan Seat QR</h4>
            <p className="text-[10px] md:text-xs text-slate-500 font-medium leading-relaxed">Scan the unique QR code located on the desk to initiate your booking and generate an OTP.</p>
          </div>
        </div>
        <div className="p-6 md:p-8 bg-white rounded-[1.5rem] md:rounded-[2.5rem] border border-slate-100 shadow-xl shadow-slate-200/20 space-y-4 group hover:shadow-2xl transition-all sm:col-span-2 md:col-span-1">
          <div className="w-10 h-10 md:w-12 md:h-12 bg-emerald-50 text-emerald-600 rounded-xl md:rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
            <CheckCircle2 className="w-5 h-5 md:w-6 md:h-6" />
          </div>
          <div className="space-y-1">
            <h4 className="font-black text-slate-900 text-sm md:text-base">3. Verify & Study</h4>
            <p className="text-[10px] md:text-xs text-slate-500 font-medium leading-relaxed">Enter your OTP within 5 minutes to activate your session and start your study time.</p>
          </div>
        </div>
      </div>

      {/* Floor Selector & Seat Grid */}
      <div className="space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-1 md:gap-2 p-1 md:p-1.5 bg-white border border-slate-100 rounded-xl md:rounded-2xl shadow-sm w-full sm:w-fit overflow-x-auto no-scrollbar">
            {[1, 2, 3].map((floor) => (
              <button
                key={floor}
                onClick={() => setSelectedFloor(floor)}
                className={cn(
                  "flex-1 sm:flex-none px-4 md:px-6 py-2 md:py-2.5 rounded-lg md:rounded-xl text-xs md:text-sm font-black transition-all whitespace-nowrap",
                  selectedFloor === floor 
                    ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" 
                    : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
                )}
              >
                Floor {floor}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between sm:justify-start gap-4 md:gap-6 px-4 md:px-6 py-3 bg-white border border-slate-100 rounded-xl md:rounded-2xl shadow-sm text-[8px] md:text-[10px] font-black uppercase tracking-widest text-slate-400">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-slate-100 border-2 border-slate-200" />
              Available
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-red-500 shadow-lg shadow-red-100" />
              Occupied
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-yellow-500 shadow-lg shadow-yellow-100" />
              Reserved
            </div>
          </div>
        </div>

        <Card className="p-4 md:p-10 border-none shadow-2xl shadow-slate-200/40 bg-white/80 backdrop-blur-md rounded-[1.5rem] md:rounded-[2.5rem]">
          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2 md:gap-4">
            <AnimatePresence mode="popLayout">
              {filteredSeats.map((seat, idx) => (
                <motion.button
                  key={seat.id}
                  layout
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ delay: idx * 0.005 }}
                  whileHover={{ scale: 1.05, y: -4 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    setSelectedSeat(seat);
                    if (seat.status === 'available') {
                      toast.info('Use the "Scan to Book" button at the top to reserve this seat.');
                    }
                  }}
                  className={cn(
                    "aspect-square rounded-xl md:rounded-2xl border-2 flex flex-col items-center justify-center gap-1 md:gap-1.5 transition-all relative group overflow-hidden",
                    seat.status === 'available' && "bg-white border-slate-100 hover:border-indigo-500 hover:shadow-2xl hover:shadow-indigo-100 text-slate-900",
                    seat.status === 'occupied' && "bg-slate-50 border-transparent text-slate-200 cursor-not-allowed",
                    seat.status === 'reserved' && "bg-yellow-50 border-yellow-200 text-yellow-700 cursor-not-allowed"
                  )}
                  disabled={seat.status !== 'available'}
                >
                  {seat.status === 'occupied' && (
                    <div className="absolute inset-0 flex items-center justify-center opacity-10">
                      <XCircle className="w-8 h-8 md:w-12 md:h-12" />
                    </div>
                  )}
                  
                  <div className={cn(
                    "w-6 h-6 md:w-8 md:h-8 rounded-md md:rounded-lg flex items-center justify-center text-[10px] md:text-xs font-black",
                    seat.status === 'available' ? "bg-indigo-50 text-indigo-600" : "bg-slate-100 text-slate-400"
                  )}>
                    {seat.number.split('-')[1]}
                  </div>

                  <span className="text-[8px] md:text-[10px] font-bold uppercase tracking-tighter opacity-60">
                    {seat.type}
                  </span>

                  {/* Status Indicator Dot */}
                  <div className={cn(
                    "absolute top-1.5 right-1.5 md:top-2 md:right-2 w-1.5 h-1.5 md:w-2 md:h-2 rounded-full",
                    seat.status === 'available' ? "bg-green-400" : seat.status === 'occupied' ? "bg-red-400" : "bg-yellow-400"
                  )} />
                  
                  {/* Tooltip (Desktop only) */}
                  <div className="hidden md:flex absolute inset-0 bg-indigo-600 text-white flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    <span className="text-[10px] font-black uppercase tracking-widest">Scan QR</span>
                    <span className="text-[8px] font-bold opacity-80">{seat.number}</span>
                  </div>
                </motion.button>
              ))}
            </AnimatePresence>
          </div>
          
          {filteredSeats.length === 0 && (
            <div className="py-20 text-center space-y-4">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto">
                <Search className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-slate-400 font-bold">No seats found matching your search</p>
            </div>
          )}
        </Card>
      </div>
      {/* QR Scanner Modal */}
      {isQRScannerOpen && (
        <QRScanner 
          onScan={handleQRScan} 
          onClose={() => setIsQRScannerOpen(false)} 
          title="Scan Seat QR Code"
        />
      )}

      {/* Verification Modal */}
      <Modal 
        isOpen={isBookingModalOpen} 
        onClose={() => setIsBookingModalOpen(false)} 
        title="Verify Seat Booking"
      >
        <div className="space-y-8">
          <div className="p-6 bg-amber-50 rounded-[2rem] border border-amber-100 flex flex-col items-center text-center gap-4">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-amber-500 shadow-sm">
              <Clock className="w-8 h-8 animate-pulse" />
            </div>
            <div className="space-y-1">
              <p className="text-lg font-black text-amber-900">Enter Verification Code</p>
              <p className="text-xs text-amber-600 font-bold uppercase tracking-widest">Expires in {timeLeft}</p>
              {booking?.otp && (
                <div className="mt-4 p-3 bg-white/50 rounded-xl border border-amber-200">
                  <p className="text-[10px] text-amber-600 font-black uppercase tracking-widest mb-1">Your Code</p>
                  <p className="text-2xl font-black text-amber-600 font-mono tracking-widest">{booking.otp}</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">6-Digit OTP</label>
              <Input 
                className="text-center text-3xl sm:text-4xl font-black tracking-[0.4em] h-16 sm:h-20 rounded-[1.2rem] sm:rounded-[1.5rem] bg-slate-50 border-none focus:ring-indigo-500" 
                placeholder="000000"
                maxLength={6}
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                value={otpInput}
                onChange={(e) => setOtpInput(e.target.value.replace(/[^0-9]/g, ''))}
              />
            </div>
            
            <div className="p-4 bg-slate-50 rounded-2xl flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-slate-400" />
              <p className="text-[10px] text-slate-500 font-bold leading-relaxed">
                The OTP is displayed on your dashboard. Enter it here to confirm you are physically present at the seat.
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Button 
              className="w-full h-14 rounded-2xl text-base font-black shadow-xl shadow-indigo-100" 
              onClick={handleVerifyOTP}
              isLoading={isVerifying}
              disabled={otpInput.length !== 6}
            >
              Confirm Presence
            </Button>
            <Button 
              variant="outline" 
              className="w-full h-12 rounded-xl text-rose-600 border-rose-100 hover:bg-rose-50 hover:border-rose-200 font-black text-[10px] uppercase tracking-widest"
              onClick={handleCancelBooking}
            >
              Cancel Reservation
            </Button>
          </div>
        </div>
      </Modal>

      <ConfirmModal 
        isOpen={isConfirmReleaseOpen}
        onClose={() => setIsConfirmReleaseOpen(false)}
        onConfirm={handleCheckout}
        title="Release Seat"
        message="Are you sure you want to release your seat? This will end your current study session."
      />

      {/* Floating Scan Button for Mobile */}
      <div className="fixed bottom-24 right-6 lg:hidden z-40">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsQRScannerOpen(true)}
          className="w-16 h-16 bg-indigo-600 text-white rounded-full shadow-2xl shadow-indigo-500/50 flex items-center justify-center border-4 border-white"
        >
          <QrCode className="w-8 h-8" />
        </motion.button>
      </div>
    </div>
  );
}
