import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage from './pages/Login';
import SignUpPage from './pages/SignUp';
import StudentDashboard from './pages/StudentDashboard';
import AdminDashboard from './pages/AdminDashboard';
import ProfilePage from './pages/Profile';
import HistoryPage from './pages/History';
import UserAccessPage from './pages/UserAccess';
import { Layout } from './components/Layout';
import { Toaster } from 'sonner';
import { ShieldCheck } from 'lucide-react';

function AppContent() {
  const { user, profile, profileError, loading, logout } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          <p className="text-slate-500 font-medium animate-pulse">Syncing your session...</p>
        </div>
      </div>
    );
  }

  if (user && profileError) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-[2rem] p-8 shadow-2xl shadow-slate-200 border border-slate-100 text-center space-y-6">
          <div className="w-20 h-20 bg-rose-50 text-rose-600 rounded-[1.5rem] flex items-center justify-center mx-auto">
            <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-900">Database Error</h2>
            <p className="text-slate-500 font-medium">
              We couldn't load your profile. This usually happens if the Supabase tables haven't been created yet.
            </p>
            <div className="p-4 bg-slate-50 rounded-2xl text-left">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Error Details</p>
              <code className="text-xs text-rose-600 font-bold break-all">{profileError}</code>
            </div>
          </div>
          <div className="pt-4 space-y-3">
            <p className="text-xs text-slate-400 font-bold">
              Please run the <code className="bg-slate-100 px-1.5 py-0.5 rounded">supabase_schema.sql</code> in your Supabase SQL Editor.
            </p>
            <button 
              onClick={() => logout()}
              className="w-full h-12 bg-slate-900 text-white rounded-xl font-black text-sm hover:bg-slate-800 transition-colors"
            >
              Sign Out & Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (user && !profile && !loading && !profileError) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-[2rem] p-8 shadow-2xl shadow-slate-200 border border-slate-100 text-center space-y-6">
          <div className="w-20 h-20 bg-amber-50 text-amber-600 rounded-[1.5rem] flex items-center justify-center mx-auto">
            <ShieldCheck className="w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-900">Profile Not Found</h2>
            <p className="text-slate-500 font-medium">
              Your account exists, but we couldn't find your profile details. This might happen if the registration was interrupted.
            </p>
          </div>
          <button 
            onClick={() => logout()}
            className="w-full h-12 bg-slate-900 text-white rounded-xl font-black text-sm hover:bg-slate-800 transition-colors"
          >
            Sign Out & Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        <Route 
          path="/login" 
          element={!user ? <LoginPage /> : <Navigate to="/" />} 
        />
        <Route 
          path="/signup" 
          element={!user ? <SignUpPage /> : <Navigate to="/" />} 
        />
        <Route 
          path="/" 
          element={
            user ? (
              <Layout>
                {profile?.role === 'admin' ? <AdminDashboard /> : <StudentDashboard />}
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/profile" 
          element={
            user ? (
              <Layout>
                <ProfilePage />
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/history" 
          element={
            user ? (
              <Layout>
                <HistoryPage />
              </Layout>
            ) : (
              <Navigate to="/login" />
            )
          } 
        />
        <Route 
          path="/users" 
          element={
            user && profile?.role === 'admin' ? (
              <Layout>
                <UserAccessPage />
              </Layout>
            ) : (
              <Navigate to="/" />
            )
          } 
        />
        <Route 
          path="/management" 
          element={
            user && profile?.role === 'admin' ? (
              <Layout>
                <AdminDashboard />
              </Layout>
            ) : (
              <Navigate to="/" />
            )
          } 
        />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <Toaster position="top-right" richColors />
    </Router>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
