import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'sonner';
import type { Seat, Booking } from '../types';

const INITIAL_SEATS: Seat[] = Array.from({ length: 60 }, (_, i) => {
  const floor = Math.floor(i / 20) + 1;
  const seatInFloor = (i % 20) + 101;
  return {
    id: `seat-${i + 1}`,
    number: `${String.fromCharCode(65 + Math.floor(i / 10))}-${seatInFloor}`,
    floor,
    type: i % 6 === 0 ? 'window' : i % 8 === 0 ? 'aisle' : 'standard',
    status: 'available',
    created_at: new Date().toISOString()
  };
});

export function useSeats() {
  const [seats, setSeats] = useState<Seat[]>([]);
  const [loading, setLoading] = useState(true);

  const loadSeats = async () => {
    try {
      const { data, error } = await supabase
        .from('seats')
        .select('*')
        .order('number');

      if (error) throw error;

      if (data && data.length > 0) {
        setSeats(data);
      } else {
        // If no seats in DB, initialize them (for demo purposes)
        const { data: insertedData, error: insertError } = await supabase
          .from('seats')
          .insert(INITIAL_SEATS)
          .select();
        
        if (insertError) throw insertError;
        setSeats(insertedData || []);
      }
    } catch (error) {
      console.error('Error loading seats:', error);
      // Fallback to initial seats if DB fails
      setSeats(INITIAL_SEATS);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSeats();
    
    // Subscribe to real-time changes
    const channel = supabase
      .channel('seats-changes')
      .on('postgres_changes', { event: '*', table: 'seats', schema: 'public' }, (payload) => {
        if (payload.eventType === 'UPDATE') {
          setSeats(prev => prev.map(s => s.id === payload.new.id ? (payload.new as Seat) : s));
        } else if (payload.eventType === 'INSERT') {
          setSeats(prev => [...prev, payload.new as Seat]);
        } else if (payload.eventType === 'DELETE') {
          setSeats(prev => prev.filter(s => s.id !== payload.old.id));
        }
      })
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const updateSeatStatus = async (seatId: string, status: Seat['status']) => {
    try {
      const { error } = await supabase
        .from('seats')
        .update({ status })
        .eq('id', seatId);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error updating seat status:', error);
    }
  };

  const addSeat = async (seat: Partial<Seat>) => {
    try {
      const { error } = await supabase
        .from('seats')
        .insert([{
          number: seat.number || 'New',
          floor: seat.floor || 1,
          type: seat.type || 'standard',
          status: 'available',
        }]);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error adding seat:', error);
    }
  };

  const removeSeat = async (id: string) => {
    try {
      const { error } = await supabase
        .from('seats')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    } catch (error) {
      console.error('Error removing seat:', error);
    }
  };

  return { seats, loading, updateSeatStatus, addSeat, removeSeat, refresh: loadSeats };
}

export function useActiveBooking(userId: string | undefined) {
  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);

  const loadBooking = async () => {
    if (!userId) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*, seats(*)')
        .eq('user_id', userId)
        .in('status', ['pending', 'active'])
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      setBooking(data);
    } catch (error) {
      console.error('Error loading booking:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBooking();
    
    // Subscribe to booking changes for this user
    const channel = supabase
      .channel(`user-booking-${userId}`)
      .on('postgres_changes', { 
        event: '*', 
        table: 'bookings', 
        schema: 'public',
        filter: `user_id=eq.${userId}`
      }, () => {
        loadBooking();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  const createBooking = async (seat: Seat) => {
    if (!userId) return;
    
    try {
      // 1. Check for existing active/pending booking
      const { data: existing, error: checkError } = await supabase
        .from('bookings')
        .select('id')
        .eq('user_id', userId)
        .in('status', ['pending', 'active']);

      if (checkError) {
        console.error('Error checking existing bookings:', checkError);
      }

      if (existing && existing.length > 0) {
        throw new Error('You already have an active or pending booking.');
      }

      // 2. Generate OTP and expiry
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const expires_at = new Date(Date.now() + 5 * 60 * 1000).toISOString(); // 5 minutes

      // 3. Create booking
      const { data, error } = await supabase
        .from('bookings')
        .insert([{
          seat_id: seat.id,
          user_id: userId,
          otp,
          status: 'pending',
          expires_at,
        }])
        .select('*, seats(*)')
        .single();

      if (error) throw error;

      // 4. Update Seat Status to Reserved
      try {
        await supabase
          .from('seats')
          .update({ status: 'reserved' })
          .eq('id', seat.id);
      } catch (seatError) {
        console.warn('Failed to update seat status to reserved, but booking created:', seatError);
      }
      
      setBooking(data);
      return data;
    } catch (error: any) {
      console.error('Error creating booking:', error);
      throw error;
    }
  };

  const generateOTP = async () => {
    if (!booking || !userId) return;
    
    try {
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const expires_at = new Date(Date.now() + 5 * 60 * 1000).toISOString();
      
      const { data, error } = await supabase
        .from('bookings')
        .update({ otp, expires_at })
        .eq('id', booking.id)
        .select('*, seats(*)')
        .single();

      if (error) throw error;
      setBooking(data);
      return otp;
    } catch (error) {
      console.error('Error generating OTP:', error);
    }
  };

  const verifyOTP = async (otp: string): Promise<boolean> => {
    if (!userId) return false;
    
    try {
      // 1. Fetch latest pending booking for user
      const { data: pendingBooking, error: fetchError } = await supabase
        .from('bookings')
        .select('*, seats(*)')
        .eq('user_id', userId)
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (fetchError || !pendingBooking) {
        console.error('No pending booking found for verification:', fetchError);
        return false;
      }

      const now = new Date().getTime();
      const expiry = pendingBooking.expires_at ? new Date(pendingBooking.expires_at).getTime() : 0;
      
      // Check if OTP matches and is NOT expired
      // Use a 10-second grace period for clock skew
      const isExpired = expiry ? (expiry + 10000) < now : true;
      
      console.log('Verifying OTP:', { 
        inputOtp: otp, 
        dbOtp: pendingBooking.otp, 
        isExpired,
        now: new Date(now).toISOString(),
        expiry: expiry ? new Date(expiry).toISOString() : 'none',
        graceExpiry: expiry ? new Date(expiry + 10000).toISOString() : 'none'
      });
      
      if (pendingBooking.otp !== otp) {
        throw new Error('Invalid verification code. Please check and try again.');
      }

      if (isExpired) {
        throw new Error('Verification code has expired. Please book the seat again.');
      }

      const nowIso = new Date().toISOString();
      
      // 2. Update booking: status = 'active', verified_at = now()
      const { data, error } = await supabase
        .from('bookings')
        .update({ 
          status: 'active', 
          verified_at: nowIso,
          expires_at: new Date(Date.now() + 1.5 * 60 * 60 * 1000).toISOString() 
        })
        .eq('id', pendingBooking.id)
        .select('*, seats(*)')
        .single();

      if (error) throw error;

      // 3. Update Seat Status to Occupied
      await supabase
        .from('seats')
        .update({ status: 'occupied' })
        .eq('id', pendingBooking.seat_id);

      setBooking(data);
      return true;
    } catch (error: any) {
      console.error('Error verifying OTP:', error);
      toast.error(error.message || 'Failed to verify OTP');
    }
    return false;
  };

  const clearBooking = async (status: 'completed' | 'cancelled' = 'completed') => {
    if (!userId || !booking) return;
    
    const bookingId = booking.id;
    const seatId = booking.seat_id;
    
    console.log(`Clearing booking ${bookingId} with status ${status}`);
    
    // Optimistically clear local state to unblock UI
    setBooking(null);
    
    try {
      const now = new Date().toISOString();
      
      // 1. Update booking status and set checkout_at = now()
      const { error: bookingError } = await supabase
        .from('bookings')
        .update({ 
          status, 
          checkout_at: now 
        })
        .eq('id', bookingId);

      if (bookingError) {
        // Fallback: If checkout_at is missing from schema cache, try updating without it
        if (bookingError.message.includes('checkout_at')) {
          console.warn('checkout_at column not found in schema cache, trying update without it...');
          const { error: fallbackError } = await supabase
            .from('bookings')
            .update({ status })
            .eq('id', bookingId);
          
          if (fallbackError) throw fallbackError;
        } else {
          throw bookingError;
        }
      }

      // 2. Update Seat Status back to Available
      const { error: seatError } = await supabase
        .from('seats')
        .update({ status: 'available' })
        .eq('id', seatId);

      if (seatError) {
        console.warn('Failed to update seat status to available:', seatError);
      }
      
      console.log('Booking cleared successfully');
    } catch (error) {
      console.error('Error clearing booking:', error);
      
      // Try to restore state if it was a transient error
      const { data } = await supabase
        .from('bookings')
        .select('*, seats(*)')
        .eq('id', bookingId)
        .in('status', ['pending', 'active'])
        .maybeSingle();
      
      if (data) {
        console.log('Restoring booking state after failure');
        setBooking(data);
      }
      throw error;
    }
  };

  return { 
    booking, 
    loading, 
    createBooking, 
    verifyOTP, 
    clearBooking, 
    refresh: loadBooking 
  };
}
