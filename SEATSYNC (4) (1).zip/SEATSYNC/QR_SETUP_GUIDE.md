# SeatSync QR Code Setup & Verification Guide

This guide explains how the QR code system works in SeatSync, how to set it up physically in your library, and how to test it during development.

## 1. How it Works (The Flow)

1.  **Admin Generates QR:** The Library Admin registers a seat in the Admin Dashboard.
2.  **Physical Placement:** The Admin prints the QR code and pastes it on the physical desk/seat in the library.
3.  **Student Scans:** A student arrives at the library, finds an available seat, and scans the QR code using the SeatSync app.
4.  **OTP Verification:** Upon scanning, the app generates a 6-digit OTP. The student enters this OTP in the app to confirm they are physically present.
5.  **Session Starts:** The seat status changes to "Occupied" and the study session begins.

## 2. Physical Setup (For Library Owners)

To set up your library physically:

1.  **Login as Admin:** Access the Admin Dashboard.
2.  **Manage Seats:** Go to the "Seat Management" section.
3.  **View QR:** Click the **QR Code icon** next to any seat.
4.  **Print:** Use the "Print Label" button to print the QR code.
5.  **Label Desks:** Stick the printed QR code on the corresponding desk (e.g., Seat A-101 gets the QR for A-101).

## 3. Testing During Development (Best for Laptops)

Since you are likely testing on a laptop where scanning a physical QR code is difficult, we have provided three ways to "scan":

### Method A: Manual Entry (Recommended for Testing)
1.  **Admin Side:** Open the Admin Dashboard, click the QR icon for a seat, and click **"Copy ID"**.
2.  **Student Side:** Click "Scan to Book", choose **"Manual"**, and paste the Seat ID.
3.  **Result:** This simulates a successful scan.

### Method B: Upload Image
1.  **Admin Side:** Take a screenshot of the QR code shown in the Admin Dashboard.
2.  **Student Side:** Click "Scan to Book", choose **"Upload"**, and select your screenshot.
3.  **Result:** The app will read the QR from the image.

### Method D: Master Library QR (One QR for All Seats)
1.  **Admin Side:** Open the Admin Dashboard and click **"Master QR"**.
2.  **Student Side:** Scan this single QR. The app will ask you: "Which seat are you at?".
3.  **Enter Seat:** Type the seat number (e.g., "A-101").
4.  **Result:** This generates the OTP for that specific seat using just one physical QR code for the whole library.

## 4. The OTP Logic
The OTP is a security layer to ensure the student is actually at the seat. 
- In the **Mock Version**: The OTP is displayed directly on the Student Dashboard after a successful scan.
- In the **Production Version**: You could send this OTP via SMS/Email or require it to be validated by a physical device at the desk.

---
*This guide helps you bridge the gap between the digital app and the physical library space.*
