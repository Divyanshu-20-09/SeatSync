# SeatSync Supabase Integration Guide

This guide provides the necessary SQL schema and integration steps to connect SeatSync with Supabase.

## 1. Database Schema (SQL)

Run the following SQL in your Supabase SQL Editor to create the required tables and enable Row Level Security (RLS).

```sql
-- 1. Profiles Table (Extends Auth)
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  full_name text,
  role text check (role in ('student', 'admin')) default 'student',
  registration_no text unique, -- For Students (e.g., 24BCE1868)
  admin_id text unique,        -- For Admins
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. Seats Table
create table seats (
  id uuid default gen_random_uuid() primary key,
  number text unique not null,
  floor integer not null,
  type text check (type in ('window', 'aisle', 'standard')) default 'standard',
  status text check (status in ('available', 'occupied', 'reserved')) default 'available',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. Bookings Table
create table bookings (
  id uuid default gen_random_uuid() primary key,
  seat_id uuid references seats(id) on delete cascade not null,
  user_id uuid references auth.users(id) on delete cascade not null,
  otp text not null,
  status text check (status in ('pending', 'active', 'completed', 'cancelled')) default 'pending',
  expires_at timestamp with time zone not null,
  verified_at timestamp with time zone,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. Logs Table
create table logs (
  id uuid default gen_random_uuid() primary key,
  action text not null,
  details jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS
alter table profiles enable row level security;
alter table seats enable row level security;
alter table bookings enable row level security;
alter table logs enable row level security;

-- Policies
create policy "Public profiles are viewable by everyone" on profiles for select using (true);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);

create policy "Seats are viewable by everyone" on seats for select using (true);
create policy "Admins can manage seats" on seats for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

create policy "Users can view own bookings" on bookings for select using (auth.uid() = user_id);
create policy "Users can create bookings" on bookings for insert with check (auth.uid() = user_id);
create policy "Users can update own bookings" on bookings for update using (auth.uid() = user_id);
create policy "Admins can view all bookings" on bookings for select using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);
```

## 2. Supabase Client Setup

Install the dependency:
`npm install @supabase/supabase-js`

Create `src/lib/supabase.ts`:
```typescript
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
```

## 3. Integration Logic

### Auth Integration
Replace the mock login in `AuthContext.tsx` with:
```typescript
const { data, error } = await supabase.auth.signInWithPassword({ email, password });
```

### Real-time Subscriptions
Use Supabase Realtime to listen for seat status changes:
```typescript
const channel = supabase
  .channel('seats-changes')
  .on('postgres_changes', { event: '*', table: 'seats' }, (payload) => {
    // Update local state
  })
  .subscribe();
```

### OTP Verification
Implement a database function or edge function to verify OTPs securely on the server side to prevent client-side tampering.
